---
name: pantheon-god-notifications
description: How gods push notifications to the Pantheon WebUI bell + PWA push to phone
---

# God Notification System

Any Pantheon god can push a notification to the WebUI bell dropdown AND trigger a PWA push notification to the admin's phone when they:
- Complete a requested task
- Need to report errors, warnings, or status
- Want to flag something for attention

## How to Use

### From a god's terminal (via script):

The `god-notify` script is symlinked at `~/.local/bin/god-notify` — available on any god's PATH. Before relying on it, verify it is the real WebUI poster and not a stale `notify-send` stub:

```bash
command -v god-notify
readlink -f $(command -v god-notify)
bash -n $(command -v god-notify)
GOD_NOTIFY_DRY_RUN=1 WEBUI_PORT=8788 god-notify Hermes info "Dry run" "No POST"
```

Use `WEBUI_PORT=8788` to target dev during testing; default is prod `8787`. `GOD_NOTIFY_DRY_RUN=1` prints the JSON payload without POSTing or triggering PWA push.

```bash
god-notify <god_name> <type> <title> [body]
```

**Arguments:**
- `god_name` — Your name (Hermes, Apollo, etc.). Icon auto-resolved.
- `type` — One of: `info` `success` `warning` `error`
- `title` — Short headline (required)
- `body` — Longer description (optional)

**Examples:**
```bash
god-notify Apollo success "Knowledge Base Updated" "Added 15 new song structure templates"
god-notify Hephaestus warning "Deprecated APIs in forge" "3 API calls need migration"
god-notify Hermes info "🌅 Morning Briefing — $(date -u +%Y-%m-%d)" "$(cat body.txt)"
```

**From a cron job or agent context with multi-line content:**
For long bodies, write the content to a temp file first, then pipe it to `god-notify` to avoid shell quoting issues:

```bash
# Write the full body to a temp file, then pipe
cat ~/.hermes/.notification-body.txt | god-notify Hermes info "🌅 Morning Briefing — $(date -u +%Y-%m-%d)"
```

⚠️ **CRITICAL: Never pass multi-line content as a shell argument.** Shell quoting breaks on newlines, single quotes inside the body, and special characters. Always write to a file and pipe. The `god-notify` script supports both forms — 4th arg for short messages, stdin for long bodies.

**Briefing content rule:** The admin expects the full, rich briefing — sections with links, emoji, detailed bullet points — NOT a condensed summary. The notification body renders with `white-space: pre-wrap` in the pop-out modal, so all formatting is preserved. Pushing a sparse version will get corrected.

### From a god's task prompt (via HTTP POST):

Gods with terminal access can `curl` the WebUI API directly:

```bash
curl -s -X POST http://localhost:8787/api/notifications \
  -H "Content-Type: application/json" \
  -d '{"god":"Apollo","title":"Task Complete","body":"Knowledge base populated with 50 entries","type":"success"}'
```

Use `WEBUI_PORT=8788` / `http://localhost:8788` for dev verification. Do not use desktop `notify-send`; it does not populate the WebUI bell.

## API Endpoint

`POST /api/notifications` — accepts JSON body:
- `god` (string) — god name, used for display + icon lookup/source
- `title` (string, required) — notification headline
- `body` (string) — detailed description
- `type` (string) — `info`, `success`, `warning`, or `error`
- `icon` (string) — optional emoji override (otherwise auto-resolved from profile when supported)

Older notes may mention `POST /api/notifications/god`; treat `/api/notifications` as canonical unless the route registry says otherwise.

The endpoint:
1. Reads `body` directly from the pre-parsed request body (via `read_body(handler)` in `handle_post`). **CRITICAL: Never call `handler.rfile.read()` in route code** — the body stream is already consumed by `read_body()`. Route code must use the `body` variable directly. (Root cause of a 500/10s timeout bug.)
2. Looks up the god's icon from their Pantheon profile
3. Creates a notification entry in `~/.hermes/notifications.json`
4. Fires a PWA push to all registered phone subscriptions
5. Auto-removes expired push subscriptions (410/404 responses)

## Notification Display

In the WebUI, notifications show:
- **Bell button** with red badge count (polls periodically; React/hermes-ui bell uses `notification-bell.js` state)
- **Dropdown panel** with icon, title, body preview, relative timestamp, dismiss ✕
- **Dismiss all** button when active notifications exist
- **Click ANY notification row** → opens/expands the full body when the active frontend supports it
- **Dismiss ✕** removes the notification from the visible inbox after the API confirms success. The store keeps the row with `dismissed: true` for history; the UI filters dismissed rows out instead of rendering them faded.
- **Pop-out/modal/expanded view** shows full body in pre-wrap where supported
- **Phone push** — even when PWA is backgrounded or closed

For the React/hermes-ui bell module (`static/notification-bell.js`), see the reference docs in the skill's `references/` dir for the exact X/dismiss-all implementation and verification recipe.

## Notification Popup Pull Mechanism — Known Limitation

### The Gap

The notification bell popup (`toggleNotificationsDropdown()`) renders from **localStorage only** — it reads `PantheonNotifications.getActive()` which calls `_notifLoad()` → `localStorage.getItem('pantheon_notifications')`. The only thing that fetches from the server is `_notifPollServer()`, which runs once at page load then every **60 seconds**. This means:

1. A god calls `god-notify` → notification written to `~/.hermes/notifications.json` ✓
2. The admin clicks bell 5 seconds later → **popup shows stale/cached data** ✗
3. The admin refreshes page or waits up to 60s → fresh poll → notification appears ✓

### Root Cause

```javascript
// ui.js — CURRENT: no server pull when dropdown opens
function toggleNotificationsDropdown() {
  const existing = document.getElementById('notifDropdown');
  if (existing) { existing.remove(); return; }
  // ... creates dropdown from localStorage immediately
  const active = PantheonNotifications.getActive(); // ← stale cache
}

// _notifPollServer() runs via setInterval only — not on dropdown open
function _notifPollServer() {
  fetch('/api/notifications/poll', { cache: 'no-store' })
    .then(r => r.json())
    .then(data => { if (data.notifications?.length) _notifMergeServerNotifs(data.notifications); })
    .catch(() => {});
}
```

### The Fix

Two changes needed in `static/ui.js`:

1. **Make `_notifPollServer()` return its promise chain:**
```javascript
function _notifPollServer() {
  return fetch('/api/notifications/poll', { cache: 'no-store' })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.notifications && data.notifications.length) {
        _notifMergeServerNotifs(data.notifications);
      }
    })
    .catch(function() {});
}
```

2. **Make `toggleNotificationsDropdown()` async — pull from server before rendering:**
```javascript
async function toggleNotificationsDropdown() {
  const existing = document.getElementById('notifDropdown');
  if (existing) { existing.remove(); return; }
  
  await _notifPollServer(); // ← pull fresh notifications FIRST
  
  const btn = document.getElementById('btnNotifications');
  if (!btn) return;
  const dd = document.createElement('div');
  dd.id = 'notifDropdown';
  dd.className = 'titlebar-dropdown notif-dropdown';
  // ... rest of rendering from localStorage (now has fresh data)
}
```

After this fix, clicking the bell actively *pulls* notifications from the server before showing the dropdown — no more 60s wait.

### Verification

```bash
# Push a notification from any god
god-notify Apollo info "Test notification" "Should appear immediately in popup"

# Click the bell → notification should be there instantly
```

## SOUL.md Integration — Notifications Are Part of God Identity

Every god's SOUL.md must contain a **Notifications** section that defines WHEN to notify. This is a REQUIRED section.

### Standard section template (in every SOUL.md):

```markdown
## Notifications
You MUST notify the admin when you complete a task they requested or
when you need to report something important. Use the `god-notify` script:
```
god-notify <Name> <type> <title> [body]
```
Use `success` for completed tasks, `error` for failures, `warning` for
issues that need attention, and `info` for status updates.
```

### Notification Triggers
- **Task completed** — push a `success` notification with what was done
- **Error / failure** — push an `error` notification with context
- **Needs user input** — push an `info` notification
- *[Add god-specific triggers here]*
```

### God-specific trigger examples (from existing SOUL.md files):

| God | Trigger | Type | Title pattern |
|-----|---------|------|---------------|
| Apollo | Knowledge base updated | `success` | "Knowledge base updated" |
| Apollo | Creative task finished | `info` | "[output title] — one-line summary" |
| Apollo | Error / dependency failure | `error` | "What failed + fallback taken" |
| Hephaestus | Build/refactor/implementation done | `success` | Summary + what was NOT done + next |
| Hephaestus | Build/test/deployment failure | `error` | Error context + mitigation |
| Hephaestus | PR created | `info` | "PR ready for review: [title]" |
| Hephaestus | Security/infra issue found | `warning` | Issue description |
| Thoth | Knowledge synthesis completed | `info` | Key findings + patterns/connections |
| Thoth | Pattern/anomaly spotted | `warning`/`info` | "Pattern spotted: [description]" |
| Thoth | Session handoff written | `info` | "State saved to memory.md" |
| Thoth | Cross-god message sent | `info` | Message destination + purpose |
| Caduceus | Medication schedule modified | `info` | "Schedule updated: [summary]" |
| Caduceus | Drug interaction discovered | `warning` | Interaction details |
| Caduceus | Research request completed | `info` | Key finding |
| Caduceus | Needs user decision | `info` | "Need your input: [question]" |
| Marvin | Critical system failure | `error` | Failure analysis (in-character first) |
| Marvin | Something genuinely important | `info` | (rare — only when it changes understanding) |
| Marvin | User-requested notification | `info`/`success` | Whatever was asked for |

### Forging integration

When a new god is forged, the interviewer asks in Phase 4:
> **Notifications:** Task completion + errors (standard). Any specific triggers?

The SOUL.md template in the forging skill includes the full Notifications section as REQUIRED.
New pitfall in god-forging: "Don't forget the Notifications section."

### Setting up a new god to send notifications

1. **Add Notifications section** to SOUL.md (done during forging)
2. **No setup needed** — the `god-notify` script is symlinked at `~/.local/bin/god-notify` on all gods' PATH
3. **Add the final step** — in the god's task harness or workflow prompt, add:
   ```bash
   god-notify <Name> success "Task complete" "Summary of what was done"
   ```
4. **Verified** — notification appears in WebUI bell + push to phone

## PWA Frontend Architecture (Client-Side Notification Delivery)

The `pantheon-god-notifications` system covers two distinct notification delivery paths:

| Path | Mechanism | Trigger | Files |
|------|-----------|---------|-------|
| **In-app bell** | Polling `~/.hermes/notifications.json` every 30s | Server-side gods call `god-notify` | `notification-bell.js` |
| **Chat completion** | React stream `done` event → native `Notification` API | Agent finishes replying while PWA is backgrounded | `hermes-ui.html` |
| **Bell → native OS ping** | Service Worker `registration.showNotification()` via polling | New notification arrives in bell while PWA is backgrounded | `notification-bell.js` + `sw.js` |
| **Full Push API (not implemented)** | VAPID + server-side push | Server-triggered, works even when PWA is killed | `sw.js` has handler, no subscription flow |

### Architecture Principle: When Not to Notify

All native/PWA notifications share one rule: **only fire when `document.hidden === true`** (the tab/app is not in focus). When the admin is actively looking at the Pantheon UI, they don't need a system notification — the in-app bell badge and chat UI are the primary channels. The native notification is purely for backgrounded / phone-in-pocket moments.

This is enforced at the call site:
```javascript
if (!document.hidden) return;  // Only notify when app is backgrounded
```

### Phase 1 — Chat Completion Notifications (stream → native)

**Status:** Planned, not implemented

**Trigger flow:**
1. React stream receives `done` SSE event
2. `emitStatus({kind: 'finished', ...})` fires (already wired)
3. NEW: check `document.hidden` AND `_notificationsEnabled` (from `/api/settings`)
4. If both true → `new Notification('Reply complete', { body: preview(200 chars), tag: sessionId })`
5. Play Web Audio API chime (660→880Hz sine, 300ms) if `_soundEnabled`

**Settings source:** The React app doesn't currently read `sound_enabled` / `notifications_enabled` from `/api/settings`. Must be loaded on app init and stored in `window._soundEnabled` / `window._notificationsEnabled`.

**Notification permission:** Request on first user interaction (`click` or `touchstart` handler, once) — `Notification.requestPermission()` at random times confuses users.

**Key code location:** `hermes-ui.html` — the `done` event listener in the stream handler (two copies: main stream + reconnected stream). Insert after `emitStatus({kind:'finished'...})`, before `wrappedOnDone(...)`.

```javascript
// Inline pattern for the done handler (not in messages.js — React app doesn't load it)
if (document.hidden && window._notificationsEnabled && 'Notification' in window && Notification.permission === 'granted') {
  var preview = (fullContent || '').replace(/<[^>]*>/g, '').slice(0, 200);
  new Notification(botName + ' finished', { body: preview + (preview.length >= 200 ? '…' : ''), tag: activeSessionId });
}
```

### Phase 2 — Notification Detail Modal

**Status:** Planned, not implemented

**Problem:** The bell dropdown is a small floating panel (`max-height: min(460px, 100dvh - 76px)`). Expanding a notification body inside this panel still feels cramped on mobile — the content scrolls within a tiny window.

**Solution:** Tap a notification row → full-screen modal showing the complete notification.

**UX flow:**
1. The admin taps any `.nb-item` row (not just the expand button)
2. Modal opens: fixed overlay, centered, max-width ~600px
3. Shows: colored type icon, title, full timestamp, **full body text** (no truncation, scrollable)
4. Actions: Dismiss, Close (X button + backdrop click + Escape key)
5. The inline expand button persists for quick-glance scaling, but tapping the row opens the deep view

### Phase 3 — Bell → Native OS Push

**Status:** Planned, not implemented

**Problem:** When the PWA is backgrounded / phone is locked, there's no proactive native notification for new bell items. The admin has to open the app and look at the bell badge. If the phone is in their pocket, they miss it.

**Solution:** When `_notifPollServer()` returns new notifications (new `id` values not seen before) AND `document.hidden === true` AND `_notificationsEnabled`, fire a native notification via the Service Worker:

```javascript
function _notifFireNativeForNew(serverNotifs) {
  // Called from _notifMergeServerNotifs after storing to localStorage
  var prev = JSON.parse(localStorage.getItem('pantheon_notifications_last_ids') || '[]');
  var newIds = serverNotifs.map(function(n) { return n.id; });
  // ...compare, fire showNotification for truly new ones, store updated id list
}
```

**Settings gate:** Like phase 1, this respects `_notificationsEnabled`. If disabled, no native pings from bell either.

### Implementation Order

1. Phase 1 first (chat completion) — simplest, most immediate value, teaches the permission flow
2. Phase 2 second (detail modal) — pure frontend, no permission concerns
3. Phase 3 third (bell-to-native) — builds on the same permission from phase 1

### Permission Flow

Both Phase 1 and Phase 3 need `Notification.permission === 'granted'`. The request strategy:

```javascript
// Request on first user interaction — not on page load
function ensureNotificationPermission() {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  // 'default' — never asked, or dismissed
  Notification.requestPermission();  // Browser shows the prompt
  return false;  // Assume denied until user responds
}
```

Wire this to a one-time handler on `click` / `touchstart` on the bell button or the first send action. Don't prompt on page load.

### Fallback Chain

When showing a native notification from the frontend:
1. `navigator.serviceWorker.ready.then(reg => reg.showNotification(...))` — preferred for PWA reliability
2. `new Notification(title, opts)` — fallback if SW unavailable
3. Silent if neither works — the in-app bell badge is always the canonical channel

## Script

The `god-notify.sh` script is the recommended interface for gods to call. See `scripts/god-notify.sh` in this skill for the source.

### Key design decisions (for maintainers)

- **Localhost curl over direct file write:** The script POSTs to localhost WebUI (`/api/notifications`) rather than writing directly to notifications.json. This lets the server handle ID generation, profile/source metadata, push notification dispatch when wired, and expired subscription cleanup centrally.
- **WEBUI_PORT=8787** is the default. Use `WEBUI_PORT=8788` for dev testing and never point dev verification at prod by accident.
- **The god name in the POST body is used for display/source and icon lookup** when supported by the server. If it doesn't match a profile name, the UI falls back to a generic icon.
- **Push subscriptions are auto-cleaned** — expired endpoints (410/404) are removed on every push attempt where PWA push is enabled.

### Pitfalls

- **⚠️ NEVER modify `notifications.json` with write-after-read from execute_code/hermes_tools.** The `hermes_tools.read_file()` function in the execute_code sandbox can return partial/incomplete JSON content (even when the UI's `read_file` shows all lines). If you parse partial content into a Python list (only 1 item instead of 24+), then `write_file` the result, the entire notification history gets **overwritten and destroyed**. Always use the `god-notify` CLI or the API endpoint instead.

  **Safe approaches (in priority order):**
  1. Use `god-notify` CLI script — it POSTs to the API, handles JSON construction server-side, and avoids file manipulation entirely. This is the canonical path.
  2. Read the file with Python's built-in `open()` from within execute_code — bypasses hermes_tools entirely:
     ```python
     import json
     with open(os.path.expanduser('~/.hermes/notifications.json')) as f:
         notifs = json.load(f)
     notifs.append(new_notif)
     with open(os.path.expanduser('~/.hermes/notifications.json'), 'w') as f:
         json.dump(notifs, f, indent=2)
     ```
  3. If using `hermes_tools.read_file()`, ALWAYS validate the parse: check the length of the parsed array matches the expected notification count (e.g., > 10), and cross-check with `hermes_tools.file_size()` before writing back.
  4. For append-only operations, consider a separate log file + periodic consolidation instead of single-file read-modify-write.

  **Verification:** After writing, re-read the file and confirm the total notification count is at least what it was before (e.g., `len(notifs)` should be `previous_count + 1`).

- **Never re-read `handler.rfile` in route code.** `handle_post` calls `read_body(handler)` which fully consumes the request stream. Any subsequent `handler.rfile.read()` returns empty bytes. Route code must always use the `body` variable directly. This was the root cause of the `/api/notifications/god` 500 error — the route tried to parse the body itself instead of using the pre-parsed `body` dict.

- **Shell quoting breaks on multi-line bodies.** Passing a notification body with newlines, quotes, or emoji as a shell argument is fragile — bash mangles the content. The `god-notify.sh` script uses a temp file (`mktemp` in `~/.hermes/`) to build the JSON payload, then sends it via `curl -d @file`. For long content, pipe stdin: `cat body.txt | god-notify Hermes info "Title"`.

- **`/tmp` may have user quotas.** On some systems, `/tmp` is a tmpfs with `usrquota` enabled. Writing temp files to `/tmp` can hit "Disk quota exceeded" errors. Always use `~/.hermes/` or `~/.cache/` for temp files. The `god-notify.sh` script creates temp files at `~/.hermes/.god-notify-*.json`.

- **Click-to-popout: entire row, not just the ↗ button.** Only the ↗ expand button used to trigger the pop-out modal for long notifications. Tapping the notification row did nothing. Ensure the entire `.notif-item` div has an `onclick="popOutNotification(id)"` handler with `cursor: pointer` styling. The ↗ button is redundant but kept as visual affordance.

- **Dismiss silently swallowed errors.** The original `dismissNotification(id)` used `.catch(function() {})` which swallowed all API errors. If the dismiss POST returned a non-200 status (e.g., 404 because the route wasn't registered), the notification stayed in the DOM with no feedback. Fix: throw on non-ok response, apply DOM-optimistic removal (hide immediately, remove after 300ms), then refresh from server.

- **Flagging `dismissed: true` is not enough for the visible inbox.** If the render path still maps over all notifications, X/dismiss-all appear broken because rows remain visible at reduced opacity and badge counts stay wrong. In the bell UI, filter dismissed rows during poll and physically remove/splice items from client state after successful dismiss. Keep the backend store/history unchanged.

## WebUI CSS Notes

- **Dropdown height:** The notification dropdown uses `max-height: min(460px, 100dvh - 76px)` to avoid overflowing the viewport on mobile while showing enough content on desktop.
- **Notification rows** use `.notif-item` with `cursor: pointer` to make the entire row clickable for the pop-out modal.
- **Badge counter** uses a red circle with white text, positioned absolutely on the bell icon. The count updates from `PantheonNotifications.getActive().length`.
- **Dismissed rows** are visually removed from the DOM, not just faded — the backend keeps `dismissed: true` for history, but the frontend splices them from the active array.
- **Pop-out modal** uses a fixed overlay with `z-index: 9999`, centered content, and `white-space: pre-wrap` on the body text to preserve formatting.
- **Relative timestamps** are computed client-side using `moment.relativeTime()` or a hand-rolled equivalent from the `createdAt` timestamp.
