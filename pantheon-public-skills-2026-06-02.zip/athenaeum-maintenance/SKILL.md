---
name: athenaeum-maintenance
description: "Athenaeum data quality management — cross-checking files against ChromaDB embeddings for coverage gaps (health check), batch entity/relation extraction from Athenaeum files into the knowledge graph (extraction pipeline), memory scoring, conflict detection, and LLM compilation of session transcripts into structured knowledge articles."
version: 2.0.0
---

# Athenaeum Maintenance

Four complementary workflows for maintaining Athenaeum data quality:

1. **Health Check** — Cross-reference every Codex file against ChromaDB embeddings to find gaps, orphans, and drift
2. **Entity Extraction Pipeline** — Batch LLM entity/relation extraction from files into the knowledge graph
3. **Memory Scoring & Conflict Detection** — Priority scoring and graph `contradicts` edges for knowledge integrity
4. **LLM Compilation Pipeline** — Convert raw session transcripts into structured knowledge articles in Codex `distilled/` directories

---

## Section A: Health Check

Run when: after re-embedding, adding new codexes, when semantic search seems incomplete.

### Full Scan

Cross-references every `Codex-*` directory against ChromaDB metadata:

```python
import chromadb
from pathlib import Path

ATH = Path('~/athenaeum')
CHR = '~/.hermes/pantheon/chroma'
client = chromadb.PersistentClient(path=CHR)
EXTS = {'.md','.txt','.json','.yaml','.yml'}

# Get all embedded sources
embedded = set()
for col in client.list_collections():
    if col.count() == 0: continue
    r = col.get(include=['metadatas'])
    if r and r.get('metadatas'):
        for m in r['metadatas']:
            if m and 'source' in m: embedded.add(m['source'])

# Scan Codex dirs
for d in sorted(ATH.iterdir()):
    if not d.is_dir() or not d.name.startswith('Codex-'): continue
    # ... scan files, count missing
```

### Fixing Gaps — Embed Strategies

Several approaches exist. On CPU-only machines (no GPU), batching via `/api/embed` is **slower** than single-file via `/api/embeddings` because Ollama serializes internally. Prefer single-file surgical for raw files, or Hades nightly for full coverage.

| | `spot-fix-embed.py` (Surgical) | `_Embedder` Bulk (Replacement) | Hades Phase 1b (Nightly) |
|---|---|---|---|
| **Embed method** | Ollama `/api/embeddings` single-file | `_Embedder` class from `ichor_hybrid.py` | `_Embedder` single-file |
| **Action** | Scans for missing gaps, embeds only those | Walk all Codexes, embed every file via `_Embedder.embed()` | Auto-embed all missing nightly |
| **Coverage** | ALL files (no skip on distilled/sessions/archive) | ALL files (skips INDEX.md, archive/, distilled/, sessions/) | ALL files, all codexes |
| **Speed** | ~22s/file (CPU-bound, 70min for 192 files) | ~15-22s/file (qwen3-embedding:0.6b) | ~22s/file, runs per-phase |
| **Auto-discovers codexes** | ✅ Yes | ✅ Yes | ✅ Yes (via discover_codexes()) |
| **Resilience** | ✅ Auto-restarts Ollama when runner wedges (3 retries) | ❌ No auto-restart (direct embed loop) | ✅ Auto-restarts Ollama via `_Embedder.is_available()` |
| **When** | Routine file gap-fill, post-restart catch-up | After model/provider switch, corrupted DB, first-time setup | Every midnight automated |
| **Risk** | None — only adds missing vectors | 30-60m window with zero embeddings (wipes first) | None — incremental |
| **Script status** | ✅ Exists at `scripts/spot-fix-embed.py` | ❌ No dedicated script yet | ✅ Built into `hades.py` |

**⛔ Batch endpoint is slower on CPU:** Ollama's `/api/embed` (array input) is counterproductive on CPU — 3-file batch took 1m45s (35s/file) vs 22s single-file. The runner serializes internally, so batching adds overhead with no parallelism. Always use single-file `/api/embeddings`.

### Current Embedder

Previously used `nomic-embed-text` (274 MB, 768-dim). Switched to `qwen3-embedding:0.6b` (639 MB, 1024-dim, 8192 native context) for better retrieval quality.

| Env Var | Purpose | Value |
|---|---|---|
| `ATHENAEUM_EMBED_PROVIDER` | Backend choice | `ollama` (local) |
| `ATHENAEUM_EMBED_MODEL` | Model name | `qwen3-embedding:0.6b` |
| `ATHENAEUM_EMBED_API_KEY` | Cloud provider fallback | Commented out (disabled) |

The `_Embedder` class in `lib/ichor_hybrid.py` reads these at runtime, using a `search_document:` instruction prefix for retrieval-optimized embeddings.

**⚠️ Mixed-embedding-space problem:** ChromaDB may still hold vectors from a previous model. Query embeddings from the new model won't align with old vectors, reducing search quality. A full wipe-and-reembed is needed after switching embedding models.

**Preference order:** (1) Hades Phase 1b background embed nightly, (2) `spot-fix-embed.py` for surgical gap-fill (auto-restart, 3 retries), (3) bulk reembed only when model/dimensions change. Prioritize distilled files first — they're the canonical knowledge articles.

```bash
# Surgical raw-file gap-fill (preferred for manual)
python3 ~/pantheon/scripts/spot-fix-embed.py

# Nuclear wipe-and-reembed (only when necessary)
ATHENAEUM_EMBED_PROVIDER=ollama \
  ATHENAEUM_EMBED_MODEL=nomic-embed-text \
  python3 ~/pantheon/scripts/reembed-athenaeum.py
# Check progress: tail -30 /tmp/spot-fix-embed.log or /tmp/reembed.log
```

> **Process lifecycle details** → `references/embed-process-lifecycle.md` for finding running embed processes, checking progress, detecting stuck processes, and resuming after crashes.

### Auto-Embed on Write

The `athenaeum_write` MCP tool auto-embeds files via `_embed_file_background()` in `mcp_server.py` (~35 lines):
- Called after every successful `athenaeum_write` for embeddable extensions (`.md`, `.txt`, `.json`, `.yaml`, `.yml`) except INDEX.md
- Non-blocking — failures logged, never raised
- Uses `_Embedder` class and `PersistentClient` (filesystem ChromaDB)
- Truncates content to 4000 chars for embedding model context limits

**Backfill:** For existing files needing embedding, use spot-fix-embed.py for incremental backfill or reembed-athenaeum.py for nuclear wipe. See `references/athenaeum-auto-embed-fix.md`.

### Reembed Script Pitfalls

- Default provider may be hardcoded — ensure defaults point to the local embedder, not a cloud provider
- **ChromaDB dimension mismatch** — switching model dimensions requires wiping the collection first; the `_Embedder` must be re-instantiated with the new model before calling `embed()`
- **Collection deletion order** — ChromaDB requires deleting child collections before parent

---

## Section B: Entity Extraction Pipeline

Batch extracts named entities and typed relationships from Codex markdown files into the knowledge graph.

### Architecture

```
Codex *.md files
  └─ extract-entities.py (standalone script)
       ├─ Stage 1: Parse & Chunk — split files into ~2000-char sections by heading
       ├─ Stage 2: LLM Extract — call LLM for entity+relation JSON per chunk
       ├─ Stage 3: Validate & Merge — type-check against allowlist, deduplicate
       └─ Stage 4: Write to Graph — store entities as nodes, relationships as edges
```

Located at `~/pantheon/scripts/extract-entities.py`. Uses direct httpx calls to the LLM API.

### Pipeline Stages

**Stage 1:** Split each markdown file by `##` headings into ~2000-char chunks, retaining heading context.

**Stage 2:** Send each chunk to the LLM with a structured extraction prompt requesting named entities (type, name, description) and typed relationships (source, target, relation type, description) as strict JSON.

**Stage 3:** Validate entity types against a hardcoded allowlist:

```python
VALID_EXTRACT_TYPES = {
    "concept", "person", "project", "tool", "system",
    "organization", "place", "event", "decision",
    "preference", "media", "skill", "fact",
}
```

Non-matching types are discarded. Duplicates identified by normalized name+type; merge updates descriptions rather than creating redundant nodes.

**Stage 4:** Entities become graph nodes; relationships become typed edges with `relation` property via `GraphClient` from `pantheon-core/gods/graph_client.py`.

### Model & API Configuration

| Env Var | Purpose | Typical Value |
|---|---|---|
| `OPENCODE_GO_API_KEY` | API key | Set in `~/.hermes/.env` |
| `OPENCODE_GO_BASE_URL` | API endpoint | `https://opencode.ai/zen/go/v1/chat/completions` |

The script sends requests directly to the OpenAI-compatible API. Bare model IDs are accepted (no `openai/` prefix). Check `/v1/models` for available models.

**Recommended model:** Minimax M2.5 — fast, clean JSON output. Avoid reasoning models (e.g. deepseek-v4-flash) for structured JSON under concurrent load — prone to read-timeouts on complex extraction prompts.

### Checkpoint & Resume

Tracks processed files in `~/.hermes/pantheon/extract-checkpoint.json`, checkpointing every 10 files.

| Flag | Behavior |
|---|---|
| _(none)_ | Skips files with unchanged mtime |
| `--force` | Reprocesses everything |
| `--workers N` | Concurrency (default: 4) |
| `--dry-run` | Preview only |

SIGINT/SIGTERM saves checkpoint before exit; double-interrupt force-exits.

**Retry logic:** Tier 1 — 5 HTTP retries with exponential backoff + jitter for 429s. Tier 2 — fallback model when primary returns unparseable JSON.

### Hades Integration (Phase 5)

```python
result = subprocess.run(
    [sys.executable, extract_script, "--workers", "4"],
    capture_output=True, text=True, timeout=3600, env=env,
)
```

- `timeout=3600` (1h max, was 1200 before patch)
- `env` assembled from `~/.hermes/.env` + `~/pantheon/.env` with `setdefault()` semantics

---

## Section C: LLM Compilation Pipeline

Converts raw session transcripts into structured knowledge articles (concept, connection, qa) in Codex `distilled/` directories. Runs as Phase 6 of Hades nightly.

### Architecture

```
state.db (un-compiled sessions)
  └─ run_compilation(limit=20)
       └─ llm_compile_session(session_id, messages, agents_md)
            ├─ 1. _classify_session() — keyword heuristics → assigned Codex
            ├─ 2. _format_transcript_md() — cleaned markdown transcript
            ├─ 3. _format_compilation_prompt() — AGENTS.md + transcript + instructions
            ├─ 4. _call_llm_for_compilation() — httpx → LLM API
            │       Returns JSON {articles, codex_verification}
            ├─ 5. _create_codex() — if LLM suggests a new Codex
            ├─ 6. Write articles to Codex/distilled/{session_id}/ as .md files
            └─ 7. Mark session compiled in state.db
```

### Codex Classification (Two Layers)

**Layer 1 — Keyword Heuristics (Fast Path):** `_classify_session()` uses `CODEX_CLASSIFIERS`, an ordered list of `(keywords, CodexName)` tuples. First-match wins; simple `kw in text.lower()` containment check. Default catch-all: `Codex-General`.

**Layer 2 — LLM Verification:** The compilation prompt includes the assigned Codex, full existing Codex list, and an instruction to verify the fit. If the LLM suggests a new Codex, `_create_codex()` creates it automatically (directory + INDEX.md + standard subdirs + classifier keyword).

### Codex-General Cluster Scan

`_scan_general_for_codexes()` (Phase 7) reads first 2000 chars of each root-level file in `Codex-General/`, extracts the first markdown heading, breaks into keywords, groups by shared keywords, and creates new Codexes for groups with **>=5 files** (capped at 3 per run).

### Dynamic Codex Discovery

`_get_all_codexes()` unions hardcoded KNOWN_CODEXES with filesystem-discovered `Codex-*` directories. Any dynamically created Codex is immediately visible to all subsystems (health checks, distillation, archive, compilation).

### `_create_codex()` Helper

```python
def _create_codex(name: str, description: str = "") -> bool:
```
Creates INDEX.md, standard subdirs (`distilled/`, `sessions/`, `archive/`), and adds classifier keyword. Idempotent (returns False if exists).

### Compilation Caveats

- `--compile` without value = `const=20`; `--no-compile` skips; omit = `default=20`
- Failed sessions NOT marked compiled — retried next run; empty-message sessions ARE marked compiled
- 20 compilations adds ~100MB peak RSS — monitor if raising `compile_limit`
- **Order-sensitive classifiers** — more specific entries must come first
- **LLM may hallucinate codex names** — `_create_codex()` handles idempotently but name persists
- **Cluster scan is title-only** — files with no headings contribute zero keywords

---

## Section D: Memory Scoring & Conflict Detection

A dependency-free Mem0/Graphiti pattern subset:

- `mnemosyne/client.py`: `score_memory_importance(text)` returns normalized `0.0–1.0` priority score. `embed_file()` writes `priority_score` into ChromaDB metadata. `query()` returns score from metadata.
- `gods/graph_client.py`: `register_fact(subject, predicate, value)` creates deterministic fact nodes. `find_conflicts_for_fact()` finds same subject+predicate with different value. `register_fact(..., link_conflicts=True)` creates bidirectional `contradicts` edges.
- Tests: `test_mnemosyne.py`, `test_graph_client.py` (20 passed expected)

### Design Constraints

- No external LLM call for scoring
- Backward compatible with existing ChromaDB metadata
- Uses `NODE_TYPE_FACT` and `EDGE_CONTRADICTS` vocabulary
- Resolved/superseded facts ignored via `metadata.conflict_status`
- ChromaDB metadata values must remain primitive JSON-compatible

### Verification

```bash
cd ~/pantheon/pantheon-core
uvx pytest tests/test_mnemosyne.py tests/test_graph_client.py -q
python3 -m py_compile mnemosyne/client.py gods/graph_client.py
```

**Note:** Existing embeddings won't gain `priority_score` until re-embedded.

---

## Section E: Embed Metadata Schema Consistency

### The Problem

Three embed paths write to ChromaDB with **different metadata schemas**, causing conflicting "unembedded file" counts between Hades reports and `spot-fix-embed.py`:

| Embed path | `source` value | `type` | Matchable by spot-fix? |
|---|---|---|---|
| `_embed_distilled()` | `"distilled"` (static string) | `"text"` | ❌ — never matches a file path |
| `_embed_raw_file()` | `str(absolute_path)` | `"raw"` | ✅ |
| `spot-fix-embed.py` | `str(absolute_path)` | _(absent)_ | ✅ |
| MCP `_embed_file_background()` | `str(absolute_path)` | `"raw"` | ✅ |

Hades uses `col.count()` while spot-fix uses metadata path matching. They diverge when: (1) distilled file entries use `source: "distilled"`, (2) same file embedded twice (distill + raw), (3) `_walk_codex_files()` and `col.count()` count different universes.

### The Fix (Upstream)

- **`_embed_distilled()`** — change `source: "distilled"` to `source: str(distilled_path)`, add `type: "distilled"`
- **`run_health_checks()`** — use unique source paths from metadata instead of raw `col.count()`
- **`_walk_codex_files()`** — clarify "files" field or include all embeddable files

### Verification Commands

```bash
# Find all non-path sources in ChromaDB
python3 -c "
import chromadb
c = chromadb.PersistentClient(path='$HOME/.hermes/pantheon/chroma')
for col in c.list_collections():
    r = col.get(include=['metadatas'])
    if not r or not r.get('metadatas'): continue
    sources = set(m['source'] for m in r['metadatas'] if m and 'source' in m)
    non_path = [s for s in sources if not s.startswith('/')]
    if non_path:
        print(f'{col.name}: {len(non_path)} non-path sources: {non_path[:5]}')
"

# Count entries per source type
python3 -c "
import chromadb
c = chromadb.PersistentClient(path='$HOME/.hermes/pantheon/chroma')
for col in c.list_collections():
    r = col.get(include=['metadatas'])
    if not r or not r.get('metadatas'): continue
    types = {}
    for m in r['metadatas']:
        if m and 'type' in m:
            types[m['type']] = types.get(m['type'], 0) + 1
        elif m and 'source' in m and m['source'] == 'distilled':
            types['distilled'] = types.get('distilled', 0) + 1
    if types:
        print(f'{col.name}: {types}')
"
```

### Orphan Vector Cleanup

See `references/chromadb-orphan-cleanup.md` for identifying orphans by path category (INDEX.md, session files, hidden dotfiles), running deletion, and verifying results. Also see `references/embed-metadata-schemas.md` for full schema reference with line-numbered source and complete fix checklist.
