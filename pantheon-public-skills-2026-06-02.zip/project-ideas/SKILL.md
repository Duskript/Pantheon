---
name: project-ideas
description: "Manage a curated list of project ideas stored in ~/pantheon/project-ideas.md. Add, list, update, organize, and remove ideas."
version: 1.2.0
---

# Project Ideas Manager

Manages a living markdown document at `~/pantheon/project-ideas.md` containing the Pantheon admin's project ideas for things to build or add to the Pantheon system.

Both Hermes (me) and the build god maintain this file. The build god's SOUL includes housekeeping duty — he is expected to proactively update statuses when things wrap up, without being told.

## File Section Structure

The file uses these top-level sections (exact entries vary):

```markdown
## 🏗️ Pantheon — Core Architecture
  ### Entry Name — Subtitle
  ### ...
## 🏛️ God Roster (Planned)
  ### God Name — Role
  ### ...
## 🏛️ Greek System Gods (Built into Pantheon Core)
  (Table of system-level architecture gods)
  ### Multi-User Pantheon Architecture
## 💼 Work Projects
  ### ...
```

Each entry uses `### Idea Name` with bullet metadata:

```markdown
### Pantheon Bridge — Inter-God Communication Layer
- **Status:** idea | planning | in-progress | shelved | done
- **Tags:** #pantheon-core #architecture
- **Added:** YYYY-MM-DD
- **Notes:** Design decisions, architecture notes, constraints.
```

## Commands

| You say | I do |
|---------|------|
| "Save this idea:..." | Append new under appropriate section |
| "What ideas do I have?" | Read + summarize by section × status |
| "Mark X as in-progress" | Update status field |
| "Mark X as done" | See status rules below |
| "Remove the Y idea" | Delete entry + scrub cross-references |
| "Show me my ideas by priority" | Order: in-progress > planning > idea > shelved |
| "Update the notes on X" | Edit Notes field with new design decisions |
| "Notify the build god about X" | Send via Pantheon Bridge (MCP primary, filesystem fallback) |

## Status Rules (⚠️ Important!)

**Two modes for marking things done — and you must decide which:**

1. **Reference entries** (architecture layers, design decisions, infrastructure specs) → set status to `done` but **keep the entry**. These hold permanent design notes, architecture decisions, and cross-context context that shouldn't be lost. Look for: detailed Notes sections, cross-references to other entries, dependency mentions. Examples: Pantheon Bridge, God SDK, Rebrand.

2. **Task entries** (a specific project, a tool, a one-off build) → **remove entirely** when marked done. Scrub ALL cross-references (tables, other entries' Notes fields, god rosters, system gods tables, data flow diagrams).

When in doubt, leave the entry and just update status. The Pantheon admin will tell you if they want it removed.

**Heuristic:** entries under "Pantheon — Core Architecture" with detailed design notes are reference entries. Entries that read like "build X" or "create Y" are task entries.

## Workflow: Notify the Build God, Don't Just Edit

When you update the project-ideas file on the Pantheon admin's behalf (status changes, removals, new info), **also send a message to the build god** via the Pantheon Bridge summarizing what changed and why. The Pantheon admin expects both: the file update for record, and the bridge message so the build god learns the pattern.

Include enough detail in the bridge message that the build god can replicate the same judgment next time (e.g., "Pantheon Bridge → done, kept as reference entry since it holds architecture decisions").

## Proactive Maintenance Directive

Do NOT wait for the Pantheon admin to point out stale statuses. When you finish a project, update its entry immediately. When you learn something was completed, update it. The build god has the same directive in his SOUL — both gods are expected to keep the list current without prompting.

The skill of noticing what's done and updating accordingly is more important than the mechanical steps of editing a markdown file.

## Workflow

1. New ideas default to **Status:** `idea`, appended at bottom of their section
2. Always tag ideas (#pantheon-core, #god, #tool, #workflow, #architecture, etc.)
3. When the Pantheon admin elaborates with design decisions, update Notes to capture them
4. When cleaning up removed task entries: do a full-file scan for dangling references
5. Correct old placeholder names when encountered
6. If status changes on an architecture entry also impact other entries' dependency notes (e.g. God SDK → done means Rebrand's notes about "depends on God SDK" should be updated), update those too
7. When a build completes an idea and the related code is committed/pushed, stage and commit `project-ideas.md` with the same change unless the Pantheon admin explicitly wants the status update to remain local. Do not report an idea-list update as part of the pushed work unless `git status` confirms it is committed or intentionally local-only.

### Build-Completion Commit Checklist

When project work touches `project-ideas.md`:

```bash
git status --short -- project-ideas.md
git diff -- project-ideas.md
git add project-ideas.md   # if the status/notes update should ship
git commit -m "docs: update project idea status"
```

If the code commit and project-ideas update are conceptually the same work, it is fine to include `project-ideas.md` in the same commit. If the code was already pushed, make a small follow-up docs commit rather than leaving the list dirty.

## Shared Context Digest Cron

A no-agent cron job runs `shared-context-digest.py` every 2h, writing a digest of recent Pantheon decisions + active tasks to `~/pantheon/shared/DIGEST.md`. This is the primary mechanism for cross-god awareness — Hermes checks it before starting significant builds.

**Pattern:** no-agent cron that writes a file, not a prompt-based delivery. Zero tokens burned.

**When the `context_dirs` plugin is built** (project idea in Pantheon — Core Architecture), this cron should be disabled — auto-injection replaces the digest.

**Script location:** `~/.hermes/scripts/shared-context-digest.py`
**Schedule:** every 2h

## Integration with Cron / Morning Briefing

The Morning Briefing cron job (fires daily at 07:05) reads `~/pantheon/project-ideas.md` and includes a status rollup in the dispatch. The script at `~/.hermes/scripts/morning-briefing.sh` collects the file content and passes it to the agent's prompt:

```bash
echo "=== PROJECT_IDEAS ==="
cat ~/pantheon/project-ideas.md
```

When you update the project ideas file, the change is automatically reflected in the next morning's briefing — no other step needed.

## WebUI Integration — Ideas Dropdown

The Pantheon WebUI (port 8787) serves the Ideas dropdown from the 💡 lightbulb button in the titlebar. All Ideas API endpoints live in `~/hermes-webui/api/routes.py` under `handle_post()`.

### API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/ideas` | GET | Returns `{ideas, sections, error}` — parses the whole file into sections with entries |
| `/api/ideas/status` | POST | Cycle an entry's status (idea→planning→in-progress→shelved→done) |
| `/api/ideas/delete` | POST | Remove an entry from a section |
| `/api/ideas/reorder` | POST | Move an entry up/down within its section |
| `/api/ideas/add` | POST | Append a new entry to a section |
| `/api/ideas/edit` | POST | Full edit: name, section, status, notes. Delete-then-rebuild approach. Auto-creates target section if it doesn't exist. |

### `POST /api/ideas/edit` Fields

```json
{
  "section_name": "current section name (required)",
  "entry_name": "current entry name (required)",
  "new_name": "renamed entry (optional, defaults to current)",
  "new_notes": "updated notes (optional, empty = clear notes)",
  "new_status": "idea|planning|in-progress|shelved|done (optional)",
  "new_section": "target section (optional, defaults to current — can move entries)"
}
```

Returns `{success, sections, error}` — callers re-render from `sections`.

### Frontend Architecture (`ui.js`)

**Important:** There are TWO `openIdeaEditor` function definitions in `~/hermes-webui/static/ui.js`. The first (around line 7436, uses `ideas-modal-*` CSS classes) is a **ghost** — dead code overshadowed by the second definition at line ~8469. The **active** implementation uses `ideas-edit-*` CSS classes, stores refs on `overlay._ideasBodyEl`, and defines `window.closeIdeaEditor` / `window.submitIdeaEdit`. Do NOT add code to the first ghost block — target the second one.

The CSS for the edit modal is in `style.css` under `/* ── Ideas Edit Modal ── */` using `ideas-edit-overlay`, `ideas-edit-card`, `ideas-edit-header`, `ideas-edit-body`, `ideas-edit-footer`, and related classes.

When the Pantheon admin clicks an idea name in the dropdown → `renderIdeasBody` fires `openIdeaEditor(sectionName, entryName, currentStatus, currentNotes, bodyEl)` → modal overlay appears with Name/Section/Status/Notes fields → Save calls `POST /api/ideas/edit` → dropdown re-renders from response sections.
