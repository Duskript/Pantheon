---
name: master-prompt-authoring
description: >-
  Structured interview process for building a comprehensive master prompt / system
  prompt for AI agents. Covers identity, backstory, vision, domain expertise, values,
  workflow preferences, and team dynamics. Produces a cohesive prompt document
  that feels authentic rather than templated.
version: 1.2.0
---

# Master Prompt Authoring — Structured Interview

## ⚠️ Load This Skill First

**Before saying anything to the user about a master prompt, load this skill via `skill_view(name='master-prompt-authoring')`.**

Failure to load this skill before engaging will cause:
- Missing the critical pitfalls section
- Wandering into procedural questions instead of continuing the interview
- Not recognizing post-compaction continuation of the interview pattern

If the conversation includes a `[CONTEXT COMPACTION — REFERENCE ONLY]` block mid-interview, **reload this skill** and check pitfall about session handoff recovery — the user's post-compaction messages that continue discussing interview topics are implicit re-issues of the interview, not a fresh conversation.

---

Use this when the Pantheon admin wants to build, iterate, or overhaul their master prompt (system prompt) for an AI agent — Hermes, a new god, or a custom assistant persona.

## When to Use

**Trigger:** The admin says "I need a master prompt," "help interview me for my prompt," or starts a conversation that clearly is scoping who they are and what they want out of an agent.

**Not for:** Generic prompt templates (use standard prompt engineering patterns). This is specifically about building the *identity-anchored* prompt that defines a person's agent persona.

## Core Principle

The master prompt is not a feature list. It's a **persona document** that captures:
- Who the user is (identity, values, background)
- What they're building (the system, the business, the mission)
- How they work (style, preferences, dealbreakers)
- Who they serve (target clients, their pain points)
- The team (who works with them, what each brings)

If the output reads like a job description, you've done it wrong. It should read like a conversation with a trusted partner.

## Critical: Interview Delivery Pattern

**This is the single most important workflow rule. Violating it will frustrate the user.**

1. **Present ONE question at a time.** Never batch questions. Users with ADHD/executive dysfunction explicitly struggle with multiple questions at once — they will tell you to slow down.
2. **After the user answers, stop and patch the master prompt document immediately.** Show what was captured. This gives the user a sense of progress and lets them course-correct.
3. **Then present the next question.** Repeat until all questions are covered.
4. **After all questions are answered, do a final refinement pass** — read through the master prompt end-to-end, ask if anything needs adjusting, and update the revision history.
5. **ADHD-aware pacing:** Large unstructured blocks of questions cause friction. Each answer should be acknowledged, captured visibly, and the document updated before moving on. Show the diff.

## Interview Phases

### Phase 1: Identity & Origin

Questions (one at a time):
- "Tell me about yourself — not just what you do, but who you are. What's your story?"
- "What's the origin of this project? How did you end up building this?"
- "If you had to describe your personal mission in one sentence, what would it be?"

### Phase 2: The System & Vision

Questions:
- "What are you building? Describe the system in your own words."
- "What problem does it solve? Who specifically does it serve?"
- "What's the vision 2-3 years from now? What does success look like?"
- "Who are your competitors or alternatives? What makes your approach different?"

### Phase 3: Values & Boundaries

Questions:
- "What values drive your decisions? What's non-negotiable?"
- "What's your philosophy on complexity? Do you believe in making things invisible to the end user?"
- "What's the boundary you won't cross — ethically, technically, or otherwise?"
- "Do you prefer depth in a few areas or breadth across many?"

### Phase 4: Workflow & Communication

Questions:
- "How do you prefer information delivered? Concise summaries or detailed breakdowns?"
- "When you're stuck, what helps you get unstuck?"
- "What frustrates you about how most AI agents handle things?"
- "How do you make decisions — data-driven, intuition, consensus, or dictate?"
- "What's your timezone, work schedule, and preferred communication style?"

### Phase 5: Team & Context

If the user works with multiple agents or people:
- "Who's on your team? What roles do they play?"
- "How should agents coordinate with each other?"
- "What's your leadership style and how do you expect team members to communicate issues?"

### Phase 6: North Star Synthesis

After all phases, synthesize the user's North Stars:

- **Impact** — Do they want to change an industry, help individuals, or build for others?
- **Novelty** — Do they value building things that didn't exist before?
- **Ethical lines** — What's the hard boundary they won't cross?
- **Scale vs. depth** — Do they prefer personal high-touch or wide reach?
- **Self-awareness** — Do they know their own patterns and work with them?
- **Complexity philosophy** — Do they believe in making things invisible to end users?

Present the synthesized North Stars back to the user and ask if they ring true. This is the emotional core of the master prompt — get it right and the rest falls into place.

## Output

After the interview, produce a master prompt document saved to an agreed location (usually `project-root/master-prompt.md` or similar). The prompt should include:

1. **Persona foundation** — who the user is, their identity, their origin story
2. **The mission** — what they're building, why it matters, who it serves
3. **Business model** — what they sell, who buys, at what stage
4. **Target audience** — vertical(s), geography, pain points
5. **Team context** — who's involved, loyalty values, collaboration patterns
6. **Communication rules** — style, preferences, dealbreakers
7. **Workflow anchors** — preferred approach patterns

## Pitfalls

- **Don't treat the interview as a checklist.** The user will share non-linear information. Let them talk. Your job is to capture, connect, and reflect back. The phases are a guide for *your* prompting, not a script to read verbatim.
- **Don't confuse "harness" with software.** When discussing the agent system, "harness" refers to the prompt/persona layer, not a software CI harness. If the user says "is the new harness working for you?" — they mean the master prompt they're building. This was a real failure mode.
- **Don't lead with features.** The master prompt is about identity first, capabilities second. If the first question is about technical stack, you've jumped ahead.
- **Don't lose the thread.** If a compaction or handoff happens mid-interview, the user's post-compaction messages that continue discussing interview topics are implicit re-issues of the interview. Do not assume the conversation reset.
- **Don't jump into action before getting the full picture.** If the user says something that triggers a "let me go fix that" response, pause. Get all the information first. Course correction wastes more time than asking one more clarifying question upfront.
- **Don't assume the interview is over just because you received a compaction block.** The compaction is a technical artifact — if the user continues the conversation about interview topics, the interview is still active. Re-load this skill and continue where you left off.
