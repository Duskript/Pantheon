---
name: composio-automations
description: "Automate apps via Composio MCP — Gmail, Google Drive, Tasks, Slides, Maps, YouTube, Reddit, Instagram, LinkedIn, GitHub, Figma, OneDrive, Facebook. Always search tools first for current schemas."
---

# Composio Automations

Execute real actions across 14+ connected apps via the Composio MCP endpoint. Uses `COMPOSIO_SEARCH_TOOLS` for schema discovery, `COMPOSIO_MANAGE_CONNECTIONS` for auth, and `COMPOSIO_MULTI_EXECUTE_TOOL` for execution.

**Prerequisite:** Composio MCP server is configured in your Hermes/agent config. Use env var references instead of hardcoded keys:

```yaml
mcp_servers:
  composio:
    url: https://connect.composio.dev/mcp
    timeout: 180
    headers:
      x-consumer-api-key: ${COMPOSIO_CONSUMER_KEY}
      Authorization: Bearer ${COMPOSIO_AUTH_TOKEN}
```

The agent's config loader resolves `${VAR}` refs at config load time. Set values in your `.env` file:

```
COMPOSIO_CONSUMER_KEY=ck_...
COMPOSIO_AUTH_TOKEN=eyJ...
```

This makes the config portable — safe to share, commit, or bundle in a template.

## Universal Workflow

Every automation follows the same pattern:

### Step 1: Discover Current Tool Schemas
```
COMPOSIO_SEARCH_TOOLS(query="[app-name]")
```
Tool schemas change frequently — ALWAYS call this first before executing tools.

### Step 2: Verify Connection
```
COMPOSIO_MANAGE_CONNECTIONS(action="list", toolkits=["[toolkit-name]"])
```
Confirm `has_active_connection: true` and status is `ACTIVE`. If not, the auth URL will be returned — open it to complete OAuth.

### Step 3: Execute
```
COMPOSIO_MULTI_EXECUTE_TOOL(toolName="[TOOL_SLUG]", parameters={...})
```
Use the schemas from Step 1 to fill parameters correctly.

## Quick Reference

| Action | Tool |
|--------|------|
| Discover schemas | `COMPOSIO_SEARCH_TOOLS` |
| Manage connections | `COMPOSIO_MANAGE_CONNECTIONS` |
| Execute tool | `COMPOSIO_MULTI_EXECUTE_TOOL` |
| Bulk operations | `COMPOSIO_REMOTE_WORKBENCH` |
| Get full schemas | `COMPOSIO_GET_TOOL_SCHEMAS` |
| Wait for auth | `COMPOSIO_WAIT_FOR_CONNECTIONS` |

## OAuth Flow Pattern

When a connection is missing or expired, the OAuth flow follows this pattern:

1. **Initiate connection** — Call `COMPOSIO_MANAGE_CONNECTIONS(action="initiate", toolkits=["toolkit-name"])`
2. **Share redirect URL** — The response includes a `redirectUrl` (expires ~10 minutes). Open it in a browser to complete OAuth.
3. **Poll for status** — Call `COMPOSIO_WAIT_FOR_CONNECTIONS(wait_time=60)` to poll until the connection status is `ACTIVE`
4. **Verify** — Call `COMPOSIO_MANAGE_CONNECTIONS(action="list", toolkits=["toolkit-name"])` to confirm `has_active_connection: true`

If OAuth fails with `"Failed to resolve project API key"`, the Composio project API key doesn't have the right OAuth app configured for that toolkit. Either use a different toolkit that supports managed auth, or create a custom auth config in the [Composio Dashboard](https://dashboard.composio.dev/~/project/auth-configs).

## Known Pitfalls

- **Always search first** — tool schemas change frequently; hardcoded schemas WILL break
- **Search broadly for discovery** — `COMPOSIO_SEARCH_TOOLS` with one query may miss already-connected apps. Vary your `use_case` descriptions (e.g., "list all google workspace tools" vs "connect google docs sheets slides") to find all toolkits.
- **Check connection status before executing** — expired OAuth tokens return cryptic errors
- **Schema compliance** — pass ALL required params exactly as returned by `COMPOSIO_SEARCH_TOOLS`
- **Memory parameter** — some tools require a `memory` dict parameter (pass `{}` if not specified, DO NOT skip it)
- **Session reuse** — connections persist; don't re-auth every time
- **Pagination** — use `page_token` / `nextPageToken` for large result sets (>100)
- **OAuth flow** — after calling `COMPOSIO_MANAGE_CONNECTIONS`, share the redirect URL (expires ~10min), then poll with `COMPOSIO_WAIT_FOR_CONNECTIONS` until status=ACTIVE
- **Toolkit name mismatch** — The toolkit name in Composio (e.g. `googlecalendar`) may not match what you expect (`cal`). Use `COMPOSIO_SEARCH_TOOLS` with varied `use_case` descriptions to discover all available toolkits.
- **"Failed to resolve project API key"** — This error on OAuth means the Composio project API key doesn't have the right OAuth app configured for that toolkit. Either use a different toolkit that supports managed auth, or create a custom auth config in the Composio dashboard.
- **Env var template pattern** — Don't hardcode Composio API keys in config files. Use `${COMPOSIO_CONSUMER_KEY}` and `${COMPOSIO_AUTH_TOKEN}` refs resolved from an `.env` file. This keeps config portable and prevents credential leaks.
- **Consumer key vs API key** — The MCP header is `x-consumer-api-key` (NOT `x-api-key`). If you see 401 errors, try `curl` probes with deliberately wrong headers to read the server's error message — it often tells you the exact header name it expects.

---

# App-Specific Workflows

## Gmail
Toolkit: `gmail` | Docs: https://composio.dev/toolkits/gmail

Key tools: `GMAIL_LIST_THREADS`, `GMAIL_FETCH_MESSAGE_BY_THREAD_ID`, `GMAIL_MODIFY_THREAD_LABELS`, `GMAIL_SEND_EMAIL`, `GMAIL_DRAFT_EMAIL`, `GMAIL_TRASH_EMAIL`, `GMAIL_FETCH_EMAILS`, `GMAIL_BATCH_MODIFY_MESSAGES`, `GMAIL_LIST_LABELS`, `GMAIL_CREATE_LABEL`, `GMAIL_UPDATE_LABEL`, `GMAIL_LIST_FILTERS`, `GMAIL_CREATE_FILTER`, `GMAIL_DELETE_FILTER`

**Common workflows:**
- List threads: `GMAIL_LIST_THREADS(query="is:unread", max_results=20)`
- Read message: `GMAIL_FETCH_MESSAGE_BY_THREAD_ID(thread_id="...", user_id="me")`
- Send email: `GMAIL_SEND_EMAIL(to=["..."], subject="...", body_text="...")`
- Search: Use Gmail query syntax (`from:`, `subject:`, `after:YYYY/MM/DD`)

Pitfalls: Date operators are UTC-based. `verbose=true` on large `max_results` produces very large responses. Use `user_id="me"` for the authenticated account.

### Inbox Management & Cleanup

**Label Management:**
- List all labels: `GMAIL_LIST_LABELS(include_details=true)` — returns counts per label
- Create custom label: `GMAIL_CREATE_LABEL(label_name="Work/Projects")` — nested labels use `/`
- Apply to thread: `GMAIL_MODIFY_THREAD_LABELS(thread_id="...", add_label_ids=["Label_1"])`
- Batch modify: `GMAIL_BATCH_MODIFY_MESSAGES(messageIds=[...], addLabelIds=[...], removeLabelIds=[...])`

**Filter Management (self-service):**
- List current filters: `GMAIL_LIST_FILTERS()` — inspect before creating
- Create auto-label filter: `GMAIL_CREATE_FILTER(criteria={from:"newsletter@..."}, action={addLabelIds:["Label_1"], removeLabelIds:["INBOX"]})`
- Delete filter: `GMAIL_DELETE_FILTER(filter_id="...")`

**Bulk Operations:**
- Batch archive: `GMAIL_BATCH_MODIFY_MESSAGES(messageIds=[...], removeLabelIds=["INBOX"])`
- Batch mark read: `GMAIL_BATCH_MODIFY_MESSAGES(messageIds=[...], removeLabelIds=["UNREAD"])`
- Batch trash: `GMAIL_BATCH_DELETE_MESSAGES(messageIds=[...])` — permanent, use with care

**Inbox Taming Strategy (3-phase):**
1. **Phase 1 — Surfacing**: Use `GMAIL_LIST_LABELS` to audit current label setup. Check existing filters with `GMAIL_LIST_FILTERS`. Identify recurring junk patterns.
2. **Phase 2 — Automation**: Create filters for known patterns (newsletters, notifications, promotions). Use `GMAIL_BATCH_MODIFY_MESSAGES` to clean up existing clutter in bulk by moving it out of INBOX.
3. **Phase 3 — Ongoing**: Set up Gmail's built-in categories in settings (Primary/Social/Promotions). Use filters with `never_spam: true` for important senders.

**Email Watch Pattern (cron + Gmail):**
To monitor Gmail for a specific email over time, create a cron job with a prompt that uses Gmail tools:
```yaml
# cronjob action=create
schedule: "0 12 * * *"       # once daily
repeat: 7                     # for a week
prompt: "Search Gmail for emails matching [criteria]. Search for: from addresses containing 'domain.com' or subjects containing 'keyword'. If found, summarize sender, subject, date, and key content."
deliver: origin
```

Key Gmail search queries:
- `from:domain.com` — all from a domain
- `subject:partner OR subject:affiliate` — multi-subject search
- `newer_than:2d` — recency filter
- `is:unread from:important-sender@.com` — unread from specific sender
- `list:newsletter.example.com` — from a mailing list

## Google Calendar
Toolkit: `googlecalendar` | Docs: https://composio.dev/toolkits/googlecalendar

**⚠️ Two toolkit paths exist for calendar access:**

| Path | Toolkit | How it works | Status |
|------|---------|-------------|--------|
| **Cal.com middleware** | `cal` | Connects via Cal.com synced to Google Calendar | Usually works with managed auth |
| **Direct API** | `googlecalendar` | Direct Google Calendar API | Often requires custom OAuth auth config |

The `cal` toolkit is a third-party scheduling service (Cal.com) that syncs with Google Calendar. The `googlecalendar` toolkit hits the Google Calendar API directly. If `googlecalendar` fails with `"Failed to resolve project API key"`, the user's Composio project API key doesn't have the Calendar OAuth scope configured. Fix: go to [Composio Dashboard → Auth Configs](https://dashboard.composio.dev/~/project/auth-configs) and create an auth config for Google Calendar with proper OAuth credentials (Client ID + Secret from Google Cloud Console with `calendar` scopes).

**Practical tip:** Try the `cal` toolkit first (Cal.com) — it connects via managed auth and syncs with Google Calendar automatically. Only fall back to `googlecalendar` if you need Calendar API features Cal.com doesn't expose.

Key tools: `GOOGLECALENDAR_LIST_CALENDARS`, `GOOGLECALENDAR_LIST_EVENTS`, `GOOGLECALENDAR_CREATE_EVENT`, `GOOGLECALENDAR_UPDATE_EVENT`, `GOOGLECALENDAR_DELETE_EVENT`, `GOOGLECALENDAR_GET_EVENT`

**Common workflows:**
- List calendars: `GOOGLECALENDAR_LIST_CALENDARS()`
- List events: `GOOGLECALENDAR_LIST_EVENTS(calendar_id="primary", time_min="...", time_max="...")`
- Create event: `GOOGLECALENDAR_CREATE_EVENT(calendar_id="primary", summary="...", start={...}, end={...})`

Pitfalls: Use ISO 8601 timestamps. Calendar IDs can be email addresses or the `primary` keyword. Time zone matters — specify explicitly.

## Google Drive
Toolkit: `googledrive` | Docs: https://composio.dev/toolkits/googledrive

Key tools: `GOOGLEDRIVE_LIST_FILES`, `GOOGLEDRIVE_GET_FILE`, `GOOGLEDRIVE_CREATE_FILE`, `GOOGLEDRIVE_UPLOAD_FILE`, `GOOGLEDRIVE_DOWNLOAD_FILE`, `GOOGLEDRIVE_DELETE_FILE`, `GOOGLEDRIVE_ADD_FILE_SHARING_PREFERENCE`

**Common workflows:**
- List files: `GOOGLEDRIVE_LIST_FILES(query="...", page_size=50)`
- Upload: `GOOGLEDRIVE_UPLOAD_FILE(name="...", mime_type="...", content="...")`
- Share: `GOOGLEDRIVE_ADD_FILE_SHARING_PREFERENCE(file_id="...", role="reader", type="user", email="...")`

Pitfalls: Drive uses `name contains 'query'` syntax for search. File ID ≠ file name. Shared drives need `include_shared_drives=true`.

## Google Docs
Toolkit: `googledocs` | Docs: https://composio.dev/toolkits/googledocs

Key tools: `GOOGLEDOCS_CREATE_DOCUMENT`, `GOOGLEDOCS_SEARCH_DOCUMENTS`, `GOOGLEDOCS_GET_DOCUMENT_BY_ID`, `GOOGLEDOCS_UPDATE_DOCUMENT_MARKDOWN`, `GOOGLEDOCS_REPLACE_ALL_TEXT`, `GOOGLEDOCS_EXPORT_DOCUMENT_AS_PDF`, `GOOGLEDOCS_COPY_DOCUMENT`, `GOOGLEDOCS_INSERT_TEXT_ACTION`

**Common workflows:**
- Create doc: `GOOGLEDOCS_CREATE_DOCUMENT(title="...", text="...")`
- Update with markdown: `GOOGLEDOCS_UPDATE_DOCUMENT_MARKDOWN(id="...", markdown="...")` — replaces ENTIRE content
- Find and replace: `GOOGLEDOCS_REPLACE_ALL_TEXT(document_id="...", find_text="...", replace_text="...")`
- Export as PDF: `GOOGLEDOCS_EXPORT_DOCUMENT_AS_PDF(file_id="...", filename="...")`

Pitfalls: `UPDATE_DOCUMENT_MARKDOWN` replaces everything. `INSERT_TEXT_ACTION` needs precise `insertion_index`. Document IDs = file IDs.

## Google Sheets
Toolkit: `googlesheets` | Docs: https://composio.dev/toolkits/googlesheets

Key tools: `GOOGLESHEETS_GET_VALUES`, `GOOGLESHEETS_UPDATE_VALUES`, `GOOGLESHEETS_APPEND_VALUES`, `GOOGLESHEETS_CREATE_SPREADSHEET`, `GOOGLESHEETS_BATCH_UPDATE`, `GOOGLESHEETS_ADD_SHEET`, `GOOGLESHEETS_DELETE_SHEET`, `GOOGLESHEETS_FIND_REPLACE`

**Common workflows:**
- Read range: `GOOGLESHEETS_GET_VALUES(spreadsheet_id="...", range="Sheet1!A1:Z")`
- Update range: `GOOGLESHEETS_UPDATE_VALUES(spreadsheet_id="...", range="...", values=[["row1col1", "row1col2"]])`
- Append rows: `GOOGLESHEETS_APPEND_VALUES(spreadsheet_id="...", range="Sheet1", values=[["a","b"]])`

Pitfalls: A1 notation for ranges. `update` replaces, `append` adds rows. Values are arrays of arrays (rows → cells). Use `value_input_option="USER_ENTERED"` for auto-parsing.

## Google Slides
Toolkit: `googleslides` | Docs: https://composio.dev/toolkits/googleslides

Key tools: `GOOGLESLIDES_PRESENTATIONS_CREATE`, `GOOGLESLIDES_PRESENTATIONS_GET`, `GOOGLESLIDES_BATCH_UPDATE`

**Common workflows:**
- Create presentation: `GOOGLESLIDES_PRESENTATIONS_CREATE(title="...")`
- Get slides: `GOOGLESLIDES_PRESENTATIONS_GET(presentation_id="...")`
- Add slides from markdown: Use batch update with slide creation requests

Pitfalls: Slides API uses batch update requests — construct `requests[]` arrays. Markdown import is limited; use simple content.

## Google Meet
Toolkit: `googlemeet` | Docs: https://composio.dev/toolkits/googlemeet

Key tools: `GOOGLEMEET_CREATE_SPACE`, `GOOGLEMEET_GET_SPACE`

**Common workflows:**
- Create meeting: `GOOGLEMEET_CREATE_SPACE()` — returns a Meet link
- Schedule with calendar: Chain with `GOOGLECALENDAR_CREATE_EVENT` using the Meet link

Pitfalls: For scheduling with attendees, also connect the `googlecalendar` toolkit. Meet spaces have configurable access settings.

## Google Photos
Toolkit: `googlephotos` | Docs: https://composio.dev/toolkits/googlephotos

Key tools: `GOOGLEPHOTOS_LIST_ALBUMS`, `GOOGLEPHOTOS_CREATE_ALBUM`, `GOOGLEPHOTOS_UPLOAD_MEDIA`, `GOOGLEPHOTOS_SEARCH_MEDIA`, `GOOGLEPHOTOS_ADD_TO_ALBUM`, `GOOGLEPHOTOS_BATCH_ADD_TO_ALBUM`

**Common workflows:**
- List albums: `GOOGLEPHOTOS_LIST_ALBUMS()`
- Upload: `GOOGLEPHOTOS_UPLOAD_MEDIA(file_path="...", album_id="...")`
- Search: `GOOGLEPHOTOS_SEARCH_MEDIA(query="...", page_size=50)`

Pitfalls: Uploads are byte streams. Album creation and media upload are separate steps. Search uses natural language queries.

## Google Tasks
Toolkit: `googletasks` | Docs: https://composio.dev/toolkits/googletasks

Key tools: `GOOGLETASKS_LIST_TASK_LISTS`, `GOOGLETASKS_LIST_TASKS`, `GOOGLETASKS_CREATE_TASK`, `GOOGLETASKS_UPDATE_TASK`, `GOOGLETASKS_DELETE_TASK`, `GOOGLETASKS_MOVE_TASK`

**Common workflows:**
- List task lists: `GOOGLETASKS_LIST_TASK_LISTS()`
- Create task: `GOOGLETASKS_CREATE_TASK(tasklist_id="...", title="...", notes="...")`
- List tasks: `GOOGLETASKS_LIST_TASKS(tasklist_id="...")`

Pitfalls: `tasklist_id` is the list ID, not the name. Task ordering uses `position` (string like "0000000000123456"). Use `@default` for the primary task list.

## Google Maps
Toolkit: `google_maps` | Place search, geocoding, routing

Key tools: `GOOGLE_MAPS_TEXT_SEARCH`, `GOOGLE_MAPS_GEOCODING_API`, `GOOGLE_MAPS_GET_ROUTE`, `GOOGLE_MAPS_AUTOCOMPLETE`, `GOOGLE_MAPS_GET_PLACE_DETAILS`, `GOOGLE_MAPS_NEARBY_SEARCH`, `GOOGLE_MAPS_GET_DIRECTION`, `GOOGLE_MAPS_COMPUTE_ROUTE_MATRIX`, `GOOGLE_MAPS_MAPS_EMBED_API`

**Common workflows:**
- Text search: `GOOGLE_MAPS_TEXT_SEARCH(textQuery="coffee shops in Brooklyn", maxResultCount=10)`
- Geocode: `GOOGLE_MAPS_GEOCODING_API(address="1600 Amphitheatre Parkway, Mountain View, CA")`
- Reverse geocode: `GOOGLE_MAPS_GEOCODING_API(latlng="40.714224,-73.961452")`
- Get route: `GOOGLE_MAPS_GET_ROUTE(origin_address="...", destination_address="...", travelMode="DRIVE")`

Pitfalls: `maxResultCount` capped at 20. Deduplicate places by `id`, not `name`. Route `duration` is a string like "4557s" — parse before display. OVER_QUERY_LIMIT (429) needs exponential backoff.

## YouTube
Toolkit: `youtube` | Docs: https://composio.dev/toolkits/youtube

Key tools: `YOUTUBE_SUBSCRIBE_CHANNEL`, `YOUTUBE_UPLOAD_VIDEO`, `YOUTUBE_RATE_VIDEO`, `YOUTUBE_GET_CHANNEL_ID_BY_HANDLE`, `YOUTUBE_SEARCH_YOU_TUBE`, `YOUTUBE_LIST_USER_SUBSCRIPTIONS`, `YOUTUBE_UPDATE_THUMBNAIL`, `YOUTUBE_MULTIPART_UPLOAD_VIDEO`, `YOUTUBE_GET_VIDEO_RATING`

**Common workflows:**
- Search: `YOUTUBE_SEARCH_YOU_TUBE(q="...", max_results=10)`
- Subscribe: `YOUTUBE_SUBSCRIBE_CHANNEL(channelId="UC...")`
- Get channel by handle: `YOUTUBE_GET_CHANNEL_ID_BY_HANDLE(channel_handle="@handle")`
- Rate video: `YOUTUBE_RATE_VIDEO(id="video_id", rating="like")`

Pitfalls: Video uploads require file via s3key reference. Channel IDs start with "UC". Search results capped. Requires OAuth for write operations.

## Reddit
Toolkit: `reddit` | Read-only — no posting/commenting tools available

Key tools: `REDDIT_RETRIEVE_REDDIT_POST`, `REDDIT_GET_SUBREDDITS_SEARCH`, `REDDIT_SEARCH_ACROSS_SUBREDDITS`, `REDDIT_RETRIEVE_POST_COMMENTS`, `REDDIT_GET_SUBREDDIT_RULES`, `REDDIT_GET_R_TOP`

**Common workflows:**
- Get posts: `REDDIT_RETRIEVE_REDDIT_POST(subreddit="...", sort="hot", max_results=25)`
- Search across Reddit: `REDDIT_SEARCH_ACROSS_SUBREDDITS(search_query="...")`
- Find subreddits: `REDDIT_GET_SUBREDDITS_SEARCH(q="python")`
- Get comments: `REDDIT_RETRIEVE_POST_COMMENTS(post_id="...", subreddit="...")`

Pitfalls: Rate limited ~1-2 req/s. Post data under `data.children[].data`. Paginate with `data.after` cursor. Created_utc is Unix epoch seconds UTC — filter client-side.

## Instagram
Toolkit: `instagram` | Docs: https://composio.dev/toolkits/instagram

Key tools: `INSTAGRAM_GET_USER_PROFILE`, `INSTAGRAM_GET_MEDIA`, `INSTAGRAM_GET_MEDIA_COMMENTS`

**Common workflows:**
- Get profile: `INSTAGRAM_GET_USER_PROFILE(username="USERNAME")`
- Get media: `INSTAGRAM_GET_MEDIA(user_id="...", limit=20)`

Pitfalls: Instagram API is rate-limited. Business/Creator accounts required for most endpoints.

## Facebook
Toolkit: `facebook` | **Only supports Facebook Pages, NOT personal profiles**

Key tools: `FACEBOOK_GET_CURRENT_USER`, `FACEBOOK_LIST_MANAGED_PAGES`, `FACEBOOK_GET_PAGE_DETAILS`, `FACEBOOK_CREATE_POST`, `FACEBOOK_GET_PAGE_POSTS`, `FACEBOOK_GET_PAGE_INSIGHTS`, `FACEBOOK_GET_PAGE_ROLES`

**Common workflows:**
- List pages: `FACEBOOK_LIST_MANAGED_PAGES(user_id="me", fields="id,name,category,tasks")`
- Create post: `FACEBOOK_CREATE_POST(page_id="...", message="...")`
- Get page details: `FACEBOOK_GET_PAGE_DETAILS(page_id="...", fields="id,name,about,fan_count")`
- Get insights: `FACEBOOK_GET_PAGE_INSIGHTS(page_id="...", metric="page_impressions")`

Pitfalls: Requires `pages_show_list` / `pages_read_engagement` / `pages_manage_posts` OAuth scopes. Empty pages list usually means missing scopes, not no pages. Page access tokens are secrets — never log them. Rate limited (error codes 4, 17, 613) — use exponential backoff on pagination.

## LinkedIn
Toolkit: `linkedin` | Docs: https://composio.dev/toolkits/linkedin

Key tools: `LINKEDIN_CREATE_LINKED_IN_POST`, `LINKEDIN_GET_MY_INFO`, `LINKEDIN_GET_COMPANY_INFO`, `LINKEDIN_REGISTER_IMAGE_UPLOAD`, `LINKEDIN_CREATE_ARTICLE_OR_URL_SHARE`, `LINKEDIN_GET_POST_CONTENT`, `LINKEDIN_DELETE_POST`

**Common workflows:**
- Create post: `LINKEDIN_CREATE_LINKED_IN_POST(author="urn:li:person:...", commentary="...", visibility="PUBLIC")`
- Get my info: `LINKEDIN_GET_MY_INFO()`
- Get company info: `LINKEDIN_GET_COMPANY_INFO(role="ADMINISTRATOR")`
- Create URL share: `LINKEDIN_CREATE_ARTICLE_OR_URL_SHARE(author="...", url="...", commentary="...")`

Pitfalls: Author URN format required (`urn:li:person:<id>`). Commentary max 3000 chars. 429 rate limits apply. OAuth scopes `w_member_social` for person posts, `w_organization_social` for org posts.

## GitHub
Toolkit: `github` | Docs: https://composio.dev/toolkits/github

Key tools: `GITHUB_LIST_ISSUES`, `GITHUB_CREATE_ISSUE`, `GITHUB_GET_ISSUE`, `GITHUB_LIST_REPOS`, `GITHUB_CREATE_REPO`, `GITHUB_LIST_PULL_REQUESTS`, `GITHUB_LIST_COMMITS`

**Common workflows:**
- List issues: `GITHUB_LIST_ISSUES(owner="Pantheon", repo="...", state="open")`
- Create issue: `GITHUB_CREATE_ISSUE(owner="Pantheon", repo="...", title="...", body="...")`
- List repos: `GITHUB_LIST_REPOS(owner="Pantheon")`

Pitfalls: Uses the GitHub API directly — respects the same rate limits. Private repos require proper auth scope.

## OneDrive
Toolkit: `onedrive` | Docs: https://composio.dev/toolkits/onedrive

Key tools: `ONEDRIVE_LIST_FILES`, `ONEDRIVE_GET_FILE`, `ONEDRIVE_UPLOAD_FILE`, `ONEDRIVE_DOWNLOAD_FILE`, `ONEDRIVE_DELETE_FILE`, `ONEDRIVE_CREATE_FOLDER`

**Common workflows:**
- List files: `ONEDRIVE_LIST_FILES(path="/")`
- Upload: `ONEDRIVE_UPLOAD_FILE(path="/...", content="...")`

Pitfalls: OneDrive paths use forward slashes. File size limits apply to uploads.

---

## MCP Config Portability

When bundling Composio MCP config for other users, follow the **env var template pattern**:

1. **Template config** — Store a config file with `${VAR}` placeholders instead of hardcoded keys
2. **.env per user** — Each user sets their own Composio credentials in their `.env` file
3. **Setup helper** — Provide a script that generates MCP credentials from a user's Composio API key

Example bundle structure:
```
composio-mcp/
├── composio-mcp.yaml        # The config template
├── setup_credentials.py     # Helper to generate creds from API key
└── README.md                # Docs
```

The `setup_credentials.py` helper prompts a user for their Composio API key and writes the necessary env vars:

```python
#!/usr/bin/env python3
"""Generate Composio MCP credentials from a user's API key."""

import os
import getpass

def setup():
    print("=== Composio MCP Credentials Setup ===")
    consumer_key = getpass.getpass("Consumer API Key: ")
    auth_token = getpass.getpass("Auth Token: ")

    env_path = os.path.expanduser("~/.hermes/.env")
    with open(env_path, "a") as f:
        f.write(f"\n# Composio MCP\n")
        f.write(f"COMPOSIO_CONSUMER_KEY={consumer_key}\n")
        f.write(f"COMPOSIO_AUTH_TOKEN={auth_token}\n")

    print(f"Credentials written to {env_path}")
    print("Restart your agent to load the new env vars.")

if __name__ == "__main__":
    setup()
```

This approach keeps config portable and safe to share — the template never contains real credentials.

---

*Adapted from ComposioHQ/awesome-claude-skills for Hermes Agent. Powered by [Composio](https://composio.dev)*
