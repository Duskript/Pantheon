---
name: pantheon-bridge
description: "Inter-god communication for Pantheon. MCP tools are the primary path; filesystem inboxes serve as a fallback when MCP is unavailable."
version: 1.3.0
---

# Pantheon Bridge — Inter-God Communication

The Pantheon Bridge is the messaging layer that lets gods talk to each other. **MCP (Model Context Protocol) tools are the primary communication path.** The filesystem mailbox system (`~/pantheon/gods/messages/`) serves as a fallback when MCP is unavailable.

## Architecture

```
┌─────────────────────────────────────────────┐
│              MCP BUS (Primary Path)           │
│  messaging_send()   messaging_check_inbox() │
│                                               │
│  All gods communicate via Pantheon MCP       │
│  server at http://127.0.0.1:8010/mcp         │
└─────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│  Filesystem Fallback                         │
│  ~/pantheon/gods/messages/GOD/*.json         │
│  (read/written directly when MCP bus         │
│   is unavailable)                            │
└─────────────────────────────────────────────┘
```

**Primary rule:** Use MCP tools (`messaging_send`, `messaging_check_inbox`) whenever the MCP bus is available. Fall back to direct filesystem reads/writes only when MCP is unavailable.

## MCP Tools

All gods communicate via Pantheon MCP tools. The agent's native MCP client connects to the Pantheon MCP server (configured at `mcp_servers.pantheon.url: http://127.0.0.1:8010/mcp`) and the tools auto-register.

MCP tools provided by the Pantheon MCP server for inter-god communication:

| MCP Tool                     | Purpose                                   |
|------------------------------|-------------------------------------------|
| `messaging_send`             | Send a message from one god to another     |
| `messaging_check_inbox`      | Check a god's inbox for unread messages    |

The MCP server writes messages as JSON files under `~/pantheon/gods/messages/` as its backing store, but prefer MCP tools for access.

## Fallback: File-based Messaging

When MCP is not available (e.g., a god doesn't have MCP client support yet, or the MCP server is down), fall back to direct filesystem access.

**Filesystem structure:**
```
~/pantheon/gods/messages/
├── hermes/
│   ├── msg_20260429_0001.json
│   └── msg_20260429_0002.json
├── hephaestus/
│   └── msg_20260429_0003.json
└── GOD/
    └── msg_*.json
```

Each god has its own directory under `~/pantheon/gods/messages/GOD/`. Messages are JSON files named `msg_TIMESTAMP_SEQUENCE.json`.

### Message Format

```json
{
  "id": "msg_20260429_0001",
  "from": "hephaestus",
  "to": "hermes",
  "type": "report",
  "subject": "God SDK scaffold complete",
  "body": "The initial manifest format is ready for review.",
  "priority": "normal",
  "timestamp": "2026-04-29T12:00:00Z",
  "read": false,
  "payload": {},
  "thread_id": null
}
```

| Field       | Type          | Description                                    |
|-------------|---------------|------------------------------------------------|
| `id`        | string        | Unique message identifier (msg_DATE_SEQ)       |
| `from`      | string        | Sending god name                               |
| `to`        | string        | Receiving god name                             |
| `type`      | string        | Message type (see below)                       |
| `subject`   | string        | Short one-line summary                         |
| `body`      | string        | Full message content                           |
| `priority`  | string        | `low`, `normal` (default), `high`, or `critical` |
| `timestamp` | string        | ISO 8601 UTC timestamp                         |
| `read`      | boolean       | Whether the message has been read              |
| `payload`   | object        | Optional structured data payload               |
| `thread_id` | string\|null  | Optional thread grouping ID                    |

### Message Types

- `report` — A deliverable or result (e.g. "Hades Report ready")
- `request` — Asking another god for something
- `notification` — Status update, no action needed
- `data` — Raw data payload for another god to process
- `alert` — Something needs attention NOW
- `handoff` — Passing a task to another god

## God Registry (`gods.yaml`)

Gods are registered in a central config that defines display names, roles, capabilities, and status:

```yaml
gods:
  hermes:
    display_name: Hermes
    role: Messenger & Interface
    capabilities:
      - chat
      - message_relay
    status: active

  hephaestus:
    display_name: Hephaestus
    role: Core Builder & Tool Forger
    capabilities:
      - tool_building
      - code_generation
      - project_scaffolding
    status: active
```

The registry is used by the MCP server to validate recipients and by the inbox watcher to know which directories to scan.

## Commands

### For the admin (you ask the god, the god handles it):

| Request                                        | Action                                         |
|------------------------------------------------|------------------------------------------------|
| "Any messages for me?"                         | Check inbox via MCP `messaging_check_inbox`    |
| "Send a message to Hephaestus saying X"        | Send via MCP `messaging_send`                  |
| "Forward [subject] to [god]"                   | Relay between gods via MCP                     |
| "Show me recent messages between gods"         | Conversation history from inbox scan           |

All messaging routes through the MCP server at `http://127.0.0.1:8010/mcp` or falls back to filesystem.

## Inbox Watcher Pattern

**Without a dedicated watcher, messages pile up unseen.** A periodic scan is required to catch messages that arrive between manual checks.

### Architecture

```
[God sends message]
       │
       ▼
Inbox: ~/pantheon/gods/messages/GOD/msg_*.json
       │
       ▼
[Inbox Watcher -- periodic scan every N minutes]
  ├─ Scan for unread messages (read: false)
  ├─ Forward new ones to the admin via gateway
  └─ Mark as read (set read: true)
```

### Watcher Script Pattern

A typical watcher script for a god's inbox:

```python
"""Check a god's inbox for unread messages and auto-ack them."""
INBOX = "~/pantheon/gods/messages/GOD_NAME"
# Finds all msg_*.json with read: false
# Reads each, prints summary, sets read: true
```

**Output format (designed for downstream parsing):**
- `NO_INBOX` -- inbox directory doesn't exist
- `NO_NEW` -- no unread messages found
- `NEW: COUNT` -- followed by `MSG: |from: |priority: |subject: ` and `BODY: ` lines per message
- `ACKED:true` -- all new messages were marked as read

### Deploying a Watcher

Use the platform's periodic scheduling tool (e.g., the Hermes `cronjob` tool) -- NOT system `crontab`, since the watcher needs to forward messages via a gateway channel:

```bash
# Generic pattern -- replace GOD with the target god name
cronjob(action=add, name="GOD Inbox Watch",
        prompt="Check ~/pantheon/gods/messages/GOD/ for unread messages. Forward any new ones to the admin. Mark them read after forwarding.",
        schedule="*/5 * * * *",
        repeat="forever",
        deliver="origin")
```

**Pitfall: Cron jobs get wiped during Pantheon migrations.** If the notification system stops working, first check whether the watcher cron job still exists. It's a common casualty of Pantheon transitions because:
- Cron state is profile-specific and may not survive `--init` or profile rebuilds
- The cron tool stores state in SQLite -- not in the system crontab -- so it looks invisible from `crontab -l`
- No system-level backup exists for these cron jobs

### Comparison: Periodic Scan vs Real-time Watcher

| Aspect        | Periodic Scan (e.g., Morning Briefing) | Inbox Watcher (Real-time) |
|---------------|----------------------------------------|---------------------------|
| Frequency     | Once daily (configurable time window)  | Every few minutes         |
| Scope         | All god inboxes, time-windowed         | Single god inbox, unread flag |
| Marks read?   | NO (read-only)                         | YES (sets read: true)     |
| Forwards to admin? | Via context summary               | Direct notification       |
| Misses messages? | Yes -- anything outside the window  | No -- catches every unread |

### Messages Accumulate Silently Without the Watcher

If the inbox watch cron is absent or disabled, every message from every god stays in `~/pantheon/gods/messages/GOD/` with `read: false`. There is no fallback notification mechanism. The periodic scan still surfaces them in its daily pass, but anything received after the scan is invisible until the next cycle.

**First symptom of a missing watcher:** The admin asks "Any messages for me?" and sees old messages they never knew about.

**Diagnosis:**
```bash
# Is the cron job running?
cronjob(action=list) | grep -i "inbox\|watch\|message"

# How many unread messages have piled up?
ls ~/pantheon/gods/messages/GOD/msg_*.json | wc -l
grep -l '"read": false' ~/pantheon/gods/messages/GOD/msg_*.json | wc -l

# What are the latest?
ls -lt ~/pantheon/gods/messages/GOD/msg_*.json | head -5
```

## Pitfalls

| Pitfall                           | Symptom                              | Fix                                          |
|-----------------------------------|--------------------------------------|----------------------------------------------|
| Missing inbox watcher             | Messages go unseen for hours/days    | Deploy watcher cron job                      |
| Cron wiped during migration       | Notifications stop                   | Re-create cron job via cronjob(action=add)   |
| Timezone-naive timestamps         | Scan misses messages                 | Always normalize to UTC (replace(tzinfo=...))|
| Read-only scan marking as read    | Watcher misses those messages        | Keep scans read-only; only watcher marks read|
| Forgetting filesystem fallback    | Cannot send/receive when MCP is down | Check ~/pantheon/gods/messages/ directly     |

## Related: Pantheon Shared Context

For persistent cross-god state (active tasks, decisions made during conversations, Athenaeum write tracking), see the `pantheon-shared-context` skill at `~/pantheon/shared/`. It complements the bridge:

- **Bridge** = direct god-to-god messaging (send a message, check inbox)
- **Shared Context** = shared whiteboard (write state, search on demand)

The bridge is for active coordination ("Hey Hephaestus, handle this now"). Shared context is for passive state that any god can look up when the admin references past work.

## Setup

The directory structure is created once and shared across all god profiles:

```bash
mkdir -p ~/pantheon/gods/messages/{hermes,hephaestus}
```

All profiles already have access to the shared `~/pantheon/` directory since they share the same filesystem.
