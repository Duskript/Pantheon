---
name: pantheon-update
description: Pull latest Pantheon from GitHub and apply only the changes — smarter than re-symlinking everything.
---

# Pantheon Update — Incremental from GitHub

## Quick Reference

```bash
# READ-ONLY CHECKS (available to ANY god via MCP):
mcp_pantheon_skill_run('pantheon-update')                                           # Full report
mcp_pantheon_skill_run('pantheon-update', '{"action": "check_updates"}')            # Git status
mcp_pantheon_skill_run('pantheon-update', '{"action": "check_drift"}')              # SOUL.md drift
mcp_pantheon_skill_run('pantheon-update', '{"action": "check_harnesses"}')          # Harness inheritance
mcp_pantheon_skill_run('pantheon-update', '{"action": "check_models"}')             # God model availability
mcp_pantheon_skill_run('pantheon-update', '{"action": "suggest_models", "model": "X", "provider": "Y"}')  # Rank alternatives

# EXECUTION (Hermes only, requires terminal):
hermes "update pantheon"                                  # Full git pull + apply changes
hermes "rollback pantheon update"                         # Revert to previous commit
```

## MCP Shared Skill — Read-Only Checks

A shared MCP skill lives at `~/athenaeum/skills/pantheon-update/` (manifest: `skill.yaml`, implementation: `scripts/run.py`). **Any god** can call it via `mcp_pantheon_skill_run('pantheon-update')` — no terminal access needed. The skill returns JSON. Ideal for monitoring, auditing, and pre-flight checks from inside a god session.

### Available Actions

| Action | What it does | Returns |
|--------|-------------|---------|
| `report` (default) | Runs all checks below | Markdown report + JSON |
| `check_updates` | Git fetch + ahead/behind count | Commits behind, dirty flag |
| `check_drift` | Each god's SOUL.md vs template | Missing sections per god |
| `check_harnesses` | Per-god extends tracking | Which gods inherit which base harnesses |
| `check_models` | God model/provider vs config | Warnings for missing providers, mismatched tiers |
| `suggest_models` | Rank available alternatives | Score-ranked suggestions |

### The `suggest_models` Scoring

When a god's intended model/provider doesn't exist on the user's Hermes install, this action ranks available alternatives:

1. **Exact match** (score 1.0) — model + provider both exist in `~/.hermes/config.yaml`
2. **Same model family** (score 0.35) — bare model name matches (e.g. `deepseek-v4-pro` → `deepseek-v4-flash:cloud`)
3. **Main default** (score 0.05) — `model.default` + `model.provider` from config
4. **Any available** (score 0.0) — any configured provider's models

### When to Use the MCP Skill vs the Full Git Flow

| Scenario | Use |
|----------|-----|
| "What's the current state of Pantheon?" | `mcp_pantheon_skill_run('pantheon-update')` — zero side effects |
| "I summoned a god and its model isn't working" | `check_models` to diagnose, then `suggest_models` to find alternatives |
| "What gods have outdated SOUL.md files?" | `check_drift` |
| "I want to actually pull the latest updates" | Full git flow below (Hermes with terminal) |

## GitHub Issues — Filing Problems and Features

When discovery (via MCP checks above) reveals a systemic issue, file it to the repo:

```bash
gh issue create \
  --repo Pantheon/Pantheon \
  --title "[Category] Brief description" \
  --label "enhancement" \
  --body "..."
```

**Labels used:** enhancement, bug, god-creation, model-config, infrastructure

### Pattern: Silent Cron Watchdog

Set up a silent cron job that checks for updates periodically and only speaks when there's news:

```yaml
# /command cron every week "check pantheon updates silently"
# Only notifies when behind > 0 — complete silence otherwise
cronjob(
  action="create",
  schedule="every 7d",
  skills=["pantheon-update"],
  prompt="Run mcp_pantheon_skill_run('pantheon-update') and report only if there are updates available (behind > 0). If up to date, say nothing."
)
```

## Full Git Update (Hermes + Terminal)

Pull latest from `Pantheon/Pantheon`, detect what actually changed, and only apply the necessary steps. No full re-symlink, no unnecessary restarts.

```bash
# Standard update
hermes "update pantheon"

# Rollback
hermes "rollback pantheon update"
```

## Prerequisites

- Pantheon cloned at `~/pantheon/` with `origin` pointing to `github.com:Pantheon/Pantheon.git`
- `git`, `systemctl --user`, `python3` in PATH
- Hermes Agent with `~/.hermes/config.yaml`

## Step-by-Step

### 1. Pre-Flight

```bash
cd ~/pantheon

echo "=== CURRENT STATE ==="
echo "Branch: $(git branch --show-current)"
echo "Commit: $(git rev-parse HEAD)"
echo "Message: $(git log -1 --pretty=%B)"

# Stash if dirty
if [ -n "$(git status --porcelain)" ]; then
  echo "⚠ Local changes detected — stashing"
  git stash push -m "pre-update-$(date +%Y%m%d_%H%M%S)"
  STASHED=true
fi
```

### 2. Pull

```bash
cd ~/pantheon

# Preview
git fetch origin main
echo "=== INCOMING ==="
git log HEAD..origin/main --oneline

# Track old HEAD for diffing
OLD_HEAD=$(git rev-parse HEAD)

# Pull
git pull --ff-only origin main && echo "✓ Pulled" || {
  echo "⚠ --ff-only failed — you may have diverged"
  echo "  Try: git pull origin main"
  exit 1
}

NEW_HEAD=$(git rev-parse HEAD)
```

### 3. Detect Changes

```bash
cd ~/pantheon

# If nothing changed, we're done
if [ "$OLD_HEAD" = "$NEW_HEAD" ]; then
  echo "Already up to date — nothing to do"
  exit 0
fi

echo "=== FILES CHANGED ==="
git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | sort

# Categorize
CHANGED_PLUGINS=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '^plugins/' || true)
CHANGED_SCRIPTS=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '^scripts/' || true)
CHANGED_SERVICES=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '\.service$' || true)
CHANGED_WEBUI_DEPS=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '^webui/requirements.txt' || true)
CHANGED_CORE_DEPS=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '^pantheon-core/requirements.txt' || true)
CHANGED_HARNESSES=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '^harnesses/' || true)
CHANGED_ENV_EXAMPLE=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '\.env\.example' || true)
```

### 4. Apply Only What Changed

#### Plugins (only if plugin files changed)

```bash
if [ -n "$CHANGED_PLUGINS" ]; then
  echo "=== Re-linking changed plugins ==="
  PLUGIN_TARGET_DIR="$HOME/.hermes/plugins"
  mkdir -p "$PLUGIN_TARGET_DIR"

  for plugin_path in $(echo "$CHANGED_PLUGINS" | grep -o 'plugins/[^/]*/' | sort -u || true); do
    plugin=$(basename "$plugin_path")
    source_path="$HOME/pantheon/$plugin_path"
    target_path="$PLUGIN_TARGET_DIR/$plugin"

    if [ ! -d "$source_path" ]; then 
      # Plugin was deleted — remove symlink
      if [ -L "$target_path" ] || [ -d "$target_path" ]; then
        rm -rf "$target_path"
        echo "✓ Removed stale plugin: $plugin"
      fi
      continue
    fi

    # Rebuild the symlink
    rm -rf "$target_path" 2>/dev/null
    ln -s "$(realpath "$source_path")" "$target_path"
    echo "✓ Symlinked plugin: $plugin"
  done
else
  echo "ℹ No plugin changes — skipping"
fi
```

#### Cron Scripts (only if script files changed)

```bash
if [ -n "$CHANGED_SCRIPTS" ]; then
  echo "=== Re-linking changed cron scripts ==="
  mkdir -p "$HOME/.hermes/scripts"

  for script_rel in $(echo "$CHANGED_SCRIPTS" | grep '^scripts/' | sed 's|^scripts/||' || true); do
    repo_script="$HOME/pantheon/scripts/$script_rel"
    target_link="$HOME/.hermes/scripts/$script_rel"

    if [ ! -f "$repo_script" ]; then
      rm -f "$target_link" 2>/dev/null
      echo "✓ Removed stale script: $script_rel"
      continue
    fi

    rm -f "$target_link" 2>/dev/null
    ln -s "$repo_script" "$target_link"
    echo "✓ Symlinked: $script_rel"
  done
else
  echo "ℹ No script changes — skipping"
fi
```

#### Systemd Services (only if service files changed)

```bash
if [ -n "$CHANGED_SERVICES" ]; then
  echo "=== Re-deploying changed service files ==="
  SERVICE_DIR="$HOME/.config/systemd/user"
  mkdir -p "$SERVICE_DIR"

  for svc_changed in $CHANGED_SERVICES; do
    name=$(basename "$svc_changed")
    src="$HOME/pantheon/$svc_changed"
    tgt="$SERVICE_DIR/$name"

    if [ ! -f "$src" ]; then
      # Service was deleted — stop and disable
      systemctl --user stop "$name" 2>/dev/null || true
      systemctl --user disable "$name" 2>/dev/null || true
      rm -f "$tgt"
      echo "✓ Removed stale service: $name"
      continue
    fi

    cp "$src" "$tgt"
    echo "✓ Updated $name"

    # Restart if it was already running
    if systemctl --user is-enabled "$name" 2>/dev/null | grep -q enabled; then
      systemctl --user restart "$name" 2>/dev/null && echo "✓ Restarted $name" || echo "⚠ Could not restart $name"
    fi
  done

  systemctl --user daemon-reload
else
  echo "ℹ No service changes — skipping restarts"
fi
```

#### Python Dependencies (only if requirements.txt changed)

```bash
if [ -n "$CHANGED_WEBUI_DEPS" ]; then
  echo "=== Updating WebUI deps ==="
  pip install -r "$HOME/pantheon/webui/requirements.txt" 2>/dev/null && echo "✓ WebUI deps updated"
fi

if [ -n "$CHANGED_CORE_DEPS" ]; then
  echo "=== Updating Pantheon Core deps ==="
  pip install -r "$HOME/pantheon/pantheon-core/requirements.txt" 2>/dev/null && echo "✓ Core deps updated"
fi

if [ -z "$CHANGED_WEBUI_DEPS" ] && [ -z "$CHANGED_CORE_DEPS" ]; then
  echo "ℹ No dependency changes — skipping"
fi
```

#### Env Example Change (notify, don't modify)

```bash
if [ -n "$CHANGED_ENV_EXAMPLE" ]; then
  echo "⚠ .env.example changed — check for new required env vars:"
  echo "  diff ~/pantheon/.env.example ~/pantheon/.env"
fi
```

### 5. Config Merge (always runs, cheap, ensures consistency)

```bash
python3 -c "
import yaml, os
config_path = os.path.expanduser('~/.hermes/config.yaml')
if not os.path.exists(config_path):
    exit(0)
with open(config_path) as f:
    config = yaml.safe_load(f) or {}
changed = False
if 'plugins' not in config:
    config['plugins'] = {}
if 'enabled' not in config['plugins']:
    config['plugins']['enabled'] = []
required = ['ichor-gates', 'pantheon-ichor-nudge', 'pantheon-shared-facts', 'rtk-rewrite']
current = config['plugins']['enabled']
for p in required:
    if p not in current:
        current.append(p)
        changed = True
if config.get('memory', {}).get('provider', '') != 'pantheon-shared-facts':
    config.setdefault('memory', {})['provider'] = 'pantheon-shared-facts'
    changed = True
if changed:
    config['plugins']['enabled'] = current
    with open(config_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False)
    print('✓ Config merged')
else:
    print('ℹ Config already up-to-date')
"
```

### 6. Post-Update Summary

```bash
cd ~/pantheon
echo "=== UPDATE COMPLETE ==="
echo "From: $(echo $OLD_HEAD | head -c 8)"
echo "To:   $(echo $NEW_HEAD | head -c 8)"
echo ""
echo "Changes applied:"
# Count files changed per category (reuse the same detection vars)
```

### 7. Rollback

```bash
cd ~/pantheon
git log --oneline -10
git checkout <previous-commit>

# Only re-deploy services that changed between those two commits
# Step 3 logic applies here too — diff between current and target

# If stashed:
git stash pop
```

## Does the Update Affect Existing Gods?

**Short answer: No — your god profiles are safe.**

The update only touches files inside `~/pantheon/` (the repo). Your existing gods live in `~/.hermes/profiles/<god>/` — their `SOUL.md`, `persona.md`, `config.yaml`, `god.json`, sessions, memories, and state are **never touched** by a `git pull`.

What *does* get updated, and how it affects gods:

| What changes | Where | Effect on existing gods |
|-------------|-------|------------------------|
| Base harnesses | `~/pantheon/harnesses/*.yaml` | ✅ Next time a god loads, it gets updated behavior via `extends` |
| Harness engine | `~/pantheon/pantheon-core/harness/` | ✅ Next invocation uses new loader/schema code |
| Plugins | `~/pantheon/plugins/` → symlinked to `~/.hermes/plugins/` | ✅ Takes effect on next Hermes Agent restart |
| Cron scripts | `~/pantheon/scripts/` → symlinked | ✅ Takes effect on next cron run |
| Service files | Re-copied + restarted | ✅ WebUI / MCP / services restart with new code |
| God profiles | `~/.hermes/profiles/<god>/` | ❌ **Never touched** — SOUL.md, persona, config, state all preserved |
| `.env` | `~/pantheon/.env` | ❌ Never touched by update |

So existing gods are **immune to disruption** but **benefit from fixes** — when a base harness or plugin gets updated upstream, those improvements flow through without any god needing manual reconfiguration.

## SOUL.md Template Drift Detection

When the base god template evolves — new required sections added to the god-creation skill, updated behavioral standards, new Ichor integration requirements — the update can detect which existing gods are missing those new sections and flag them for review.

### How It Works

The repo defines a canonical SOUL.md template at `god-packages/god-template/SOUL.md` (or alternatively at `gods/SOUL-template.md`). This template reflects the latest standard from the god-creation process. The update skill compares each existing god's SOUL.md against the template and reports any missing sections.

### Required Sections (Current Standard)

From the god-creation skill, every SOUL.md must have:

```
- Identity
- Domain
- Persona [RECOMMENDED — or reference to persona.md]
- How We Work Together
- Skills [CONDITIONAL]
- Ichor Integration — Tier A Extraction  [REQUIRED]
- Filesystem Access — Allowed / Off limits
- Topic-Shift Detection Protocol (auto-compact)  [REQUIRED]
- Shared Brain Protocol  [REQUIRED]
- Delegation [CONDITIONAL]
- Git Discipline / Code Changes [CONDITIONAL]
- Notifications  [REQUIRED]
- Shared Context  [REQUIRED]
- Fallback Behavior  [REQUIRED]
```

### Drift Check — Reports Missing Sections, Then Asks

```bash
echo "=== SOUL.md Template Drift Check ==="

TEMPLATE_SOUL="$HOME/pantheon/god-packages/god-template/SOUL.md"
if [ ! -f "$TEMPLATE_SOUL" ]; then
  echo "⚠ No canonical template at $TEMPLATE_SOUL — skipping drift check"
  exit 0
fi

# Read required sections from template (lines starting with "## ")
REQUIRED_SECTIONS=()
while IFS= read -r line; do
  section=$(echo "$line" | grep '^## ' | sed 's/^## //' | grep -v '^Schema:' | grep -v '^Created:' | grep -v '^Latest')
  if [ -n "$section" ]; then
    REQUIRED_SECTIONS+=("## $section")
  fi
done < "$TEMPLATE_SOUL"

DRIFT_FOUND=false
for profile_dir in ~/.hermes/profiles/*/; do
  god_name=$(basename "$profile_dir")
  soul_md="$profile_dir/SOUL.md"

  if [ ! -f "$soul_md" ]; then
    echo "⚠ $god_name: no SOUL.md — needs full forging"
    DRIFT_FOUND=true
    continue
  fi

  missing=()
  for section in "${REQUIRED_SECTIONS[@]}"; do
    if ! grep -q "$section" "$soul_md" 2>/dev/null; then
      missing+=("$section")
    fi
  done

  if [ ${#missing[@]} -gt 0 ]; then
    echo "⚠ $god_name is missing ${#missing[@]} section(s):"
    for s in "${missing[@]}"; do
      echo "   - $s"
    done
    DRIFT_FOUND=true
  else
    echo "✅ $god_name SOUL.md is current"
  fi
done
```

**When running this update via Hermes:** After the drift report, the agent asks the user: "I found N gods with drift — want me to patch the missing sections?" If yes, it opens each missing SOUL.md with the template block for that section and offers to insert it with sensible defaults.

The patching is NEVER automatic — always user-consented, one god at a time.

### What Section Drift Means for Each God

| Missing Section | Impact | Fix |
|----------------|--------|-----|
| `## Ichor Integration` | God isn't contributing to the shared memory engine | Add the standard Ichor block from god-creation skill |
| `## Filesystem Access` | No defined boundaries — god may overreach or under-reach | Add allowed/off-limits paths |
| `## Notifications` | God won't push alerts to the WebUI bell | Add notification config block |
| `## Shared Context` | God won't read/write the shared digest | Add shared context protocol |
| `## Fallback Behavior` | No defined behavior when god is out of its depth | Add fallback routing |

The check is non-destructive — it only reports. The user decides what to patch and how.

### Template Source

The canonical template can be stored in the repo at:

```
~/pantheon/god-packages/god-template/SOUL.md    ← The latest standard
```

When the template changes upstream (new sections added, old ones deprecated), the drift check catches it on the next update.

## Intelligent Harness Patching

When a harness definition in `~/pantheon/harnesses/` changes upstream, any gods whose per-god harness extends that base can optionally be patched to pick up new fields, routing rules, or guardrails — while preserving their customizations.

### How Harness Inheritance Works

```
~/pantheon/harnesses/hermes-base.yaml       ← Repo: base template
~/pantheon/god-packages/god-apollo/harness.yaml  ← Per-god: extends hermes-base.yaml
```

The `loader.py` merge logic already handles:
- `routing` — child rules prepended before base rules (child overrides win)
- `guardrails.hard_stops` — child stops appended after base stops
- `guardrails.soft_boundaries` — child replaces base
- Nested dicts — recursively merged
- All other fields — child value wins

### Patch Flow (on update)

```bash
# After pulling, check which base harnesses changed
CHANGED_HARNESSES=$(git diff --name-only "$OLD_HEAD".."$NEW_HEAD" | grep '^harnesses/.*.yaml$' || true)

if [ -n "$CHANGED_HARNESSES" ]; then
  echo "=== Checking for affected per-god harnesses ==="
  for base_harness in $CHANGED_HARNESSES; do
    base_name=$(basename "$base_harness" -base.yaml)

    # Check if any per-god harness extends this base
    for god_pkg in ~/pantheon/god-packages/god-*/harness.yaml; do
      if [ ! -f "$god_pkg" ]; then continue; fi
      extends=$(grep 'extends:' "$god_pkg" | awk '{print $2}')
      if [ "$extends" = "$(basename "$base_harness")" ]; then
        god_name=$(basename "$(dirname "$god_pkg")" | sed 's/^god-//')
        echo "⚠ $god_name's harness extends $base_harness — may need review"
        echo "  File: $god_pkg"
        echo "  Run: diff ~/pantheon/$base_harness $god_pkg"
      fi
    done
  done
fi
```

This doesn't auto-patch (that would be destructive) — it *flags* affected gods and shows the diff. **When running via Hermes:** the agent asks the user "Base harnesses changed in this update — want to review the per-god overrides?" and presents the diffs for each affected god. You approve each one or skip it.

### Manual Harness Patch Pattern

If a base harness adds a new guardrail or routing rule and you want to propagate it:

```bash
cd ~/pantheon

# See what changed in the base
git diff "$OLD_HEAD".."$NEW_HEAD" -- harnesses/hermes-base.yaml

# Check if your per-god harness already has its own version
grep -A5 'guardrails:' god-packages/god-apollo/harness.yaml

# If the new base rule doesn't conflict, extend instead of copy
# (Makes future updates automatic)
```

## ⚠️ Pitfalls

- **git diff --name-only needs both SHAs**: Works on the pull range. If `OLD_HEAD` and `NEW_HEAD` are the same, nothing changed — skip everything.
- **Plugin dir paths**: `git diff --name-only` shows `plugins/foo/bar.py`; use `grep -o 'plugins/[^/]*/'` to extract the plugin directory name.
- **Deleted plugins/services/scripts**: Detection handles this — if the source file is gone, cleanup runs.
- **Hermes venv vs system pip**: If Hermes runs in its own venv, use `~/.hermes/hermes-agent/venv/bin/pip` instead of bare `pip`.
- **Service files that don't exist yet**: `systemctl is-enabled` returns non-zero for disabled services; the script only restarts enabled ones.
- **First pull after install**: `OLD_HEAD` may not exist if this is a new install. Skip the diff comparison and do a full redeploy.

## Verification Checklist

- [ ] `git log -1` shows the expected new commit
- [ ] Changed plugins are correctly symlinked: `ls -la ~/.hermes/plugins/`
- [ ] Changed scripts linked: `ls -la ~/.hermes/scripts/`
- [ ] Changed services restarted: `systemctl --user is-active pantheon-webui pantheon-mcp demeter-watcher`
- [ ] Config plugins intact: `hermes config get plugins.enabled`
